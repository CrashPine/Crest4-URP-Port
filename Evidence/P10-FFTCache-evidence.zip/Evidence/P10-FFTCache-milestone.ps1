﻿$ErrorActionPreference='Stop'
$editor='C:/Program Files/Unity/Hub/Editor/6000.6.5f1/Editor/Unity.exe'
$events=@()
foreach($step in @(
 @{Action='EditMode';API='DX11'},@{Action='EditMode';API='DX11';Interactive=$true},
 @{Action='EditMode';API='DX12'},@{Action='EditMode';API='DX12';Interactive=$true},
 @{Action='Development';API='DX11'},@{Action='Release';API='DX11'})) {
 $name="$($step.Action)-$($step.API)"+$(if($step.Filter){'-focused'}else{''})+$(if($step.Interactive){'-interactive'}else{''})
 if(@($events | Where-Object { $_.step -eq $name -and $_.status -eq 'PASSED' }).Count -gt 0){continue}
 $entry=[ordered]@{step=$name;startUtc=[DateTime]::UtcNow.ToString('o');status='RUNNING'};$events+=$entry
 $events | ConvertTo-Json -Depth 5 | Set-Content Evidence/P10-FFTCache-operations.json -Encoding utf8
 if($step.Action -eq 'Development') {
 @'
from pathlib import Path
import subprocess,zipfile
paths=['Assets/Crest/Crest-Examples/Examples/Materials/Examples_Material_TransparentPrimitive.mat','Assets/Crest/Crest-Examples/Shared/Materials/OffWhite.mat']
with zipfile.ZipFile('Evidence/P10-FFTCache-material-side-effects.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in paths:z.write(name,name);z.writestr(name+'.diff',subprocess.check_output(['git','diff','--',name]))
for name in paths:Path(name).write_bytes(subprocess.check_output(['git','show','HEAD:'+name]))
'@ | py -
 if($LASTEXITCODE -ne 0){throw 'Material snapshot failed'}
 }
 if($step.Filter){./Tools/Run-Unity.ps1 -Editor $editor -Action $step.Action -GraphicsAPI $step.API -TestFilter $step.Filter}
 elseif($step.Interactive){./Tools/Run-Unity.ps1 -Editor $editor -Action $step.Action -GraphicsAPI $step.API -Interactive}
 else{./Tools/Run-Unity.ps1 -Editor $editor -Action $step.Action -GraphicsAPI $step.API}
 if($step.Action -eq 'EditMode'){Copy-Item "Evidence/$name.xml" "Evidence/P10-FFTCache-$name.xml"}
 $entry.status='PASSED';$entry['endUtc']=[DateTime]::UtcNow.ToString('o')
 $events | ConvertTo-Json -Depth 5 | Set-Content Evidence/P10-FFTCache-operations.json -Encoding utf8
}
foreach($config in @('Development','Release')){foreach($api in @('DX11','DX12')){
 [ordered]@{step="Player-$config-$api";status='RUNNING';startUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content Evidence/P10-FFTCache-player-operation.json
 ./Tools/Run-Player.ps1 -Player "Builds/$config/CrestPort.exe" -GraphicsAPI $api -Label $config -ReflectionOptions
 [ordered]@{step="Player-$config-$api";status='PASSED';endUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress | Add-Content Evidence/P10-FFTCache-player-completions.jsonl
}}
