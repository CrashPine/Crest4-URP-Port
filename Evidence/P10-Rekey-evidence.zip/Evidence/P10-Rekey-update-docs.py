from pathlib import Path
p=Path('PORT_PLAN.md');s=p.read_text();start=s.index('**NEXT: generator re-key ownership.**');end=s.index(' Keep GPU timing',start)
s=s[:start]+'''**DONE (scoped): generator re-key ownership and frozen-time invalidation.** Existing-target convergence originally orphaned10 native textures; no-target adaptation at unchanged time returned stale spectrum output. Evicted generators now remain owned until ocean command submission/full cleanup; cached results require initialized spectrum. Focused5/API/full115+interactive2/API, both builds/4 smokes pass. Existing target remains byte-identical, old consumer recovers exactly, adapted output matches fresh new-condition output; all16 already-queued EditMode layers remain valid. **NEXT: geometry resource inventory.** Inspect OceanBuilder s_Meshes, generated tile/root/proxy resources and existing coverage; then one bounded identity-based create/rebuild/destroy control per API with normal and changed geometry density/LOD settings, preserving original geometry algorithms. Verify every generated Mesh is destroyed after cleanup, including patch meshes not assigned to a tile. Do not repeat accepted FFT/counter/retention windows.''' +s[end:]
s=s.replace('Current full113+interactive2/API','Current full115+interactive2/API').replace('has113+interactive2/API','has115+interactive2/API');p.write_text(s)
p=Path('FEATURE_MATRIX.md');s=p.read_text().replace('Generator re-key ownership unaccepted.','Re-key convergence/frozen-time invalidation fixed:10 orphan textures now disposed after submission, unchanged target/old consumer/all16 queued layers preserved; focused5/API/full115+interactive2/API/rebuilt4 Players pass. Geometry Mesh identity/rebuild disposal remains unaccepted.');p.write_text(s)
p=Path('MIGRATION.md');s=p.read_text()+'''
### FFT condition changes and queued commands

When a condition key converges to an existing FFT generator, the removed generator remains owned in a retirement queue until OceanRenderer submits the shared simulation command buffer. Full FFT cleanup also drains that queue. Immediate release inside OnGenerationDataUpdated would invalidate commands already recorded for another input. An existing destination generator/output remains unchanged; a consumer of the former conditions can recreate its generator. The simulation-time fast path requires both generator and spectrum initialization, so an invalidated spectrum recomputes even when time is frozen. Condition hashing, compute math, dispatch and once-per-ocean update scheduling are preserved. The bounded regression covers16-layer queued EditMode output and same-time adaptation; it does not accept arbitrary external command-buffer lifetimes beyond the ocean submission contract.
''';p.write_text(s)
p=Path('TEST_RESULTS.md');s=p.read_text();at=s.index('## P10:');s=s[:at]+'''## P10: FFT condition re-key and frozen-time invalidation (2026-11-05)

Original convergence from wind10 to an already-existing wind20 key removes the old dictionary entry without releasing its2 Texture2D/8 RenderTexture resources:10 remain alive after eviction and even after full cache cleanup. Separately, adapting a generator to a new condition invalidates its spectrum, but the unchanged-time fast path returns old bytes: adapted output fails equality with freshly generated new-condition output. Runtime failure XML/native reports/exact sources and assemblies retained in P10-Rekey-runtime-failure.zip. Original queued-command control passes; two initial test setup NullReference failures are preserved in separate queued-fixture-failure archives, not classified as production defects. Real EditMode Ocean OnEnable/OnDisable supplies the fixture context.

Correction retains evicted generators until OceanRenderer command submission/full cleanup, then releases both resource groups; the timestamp cache also requires initialized generator/spectrum. Compute algorithms, condition hashing and dispatch unchanged. Focused5/5 each API; full115/115 plus actual interactive2/2 each API Passed. Native controls:10 old textures destroyed, cache1 after merge, existing destination output/bytes preserved, old-condition consumer exactly recovers all16 layers, no orphan after cleanup. Adapted RT reused and its frozen-time output equals fresh new-condition output while differing from old wind. All16 layers copied by commands queued before eviction equal the recreated consumer in EditMode on both APIs. Prior shared-owner/frozen-time/mixed destruction tests still pass.

Both normal Development/Release builds succeed;4 fresh Player smokes Errors0,28 current-frame capture pairs and no RenderData warnings. Selected fresh waves/underwater images inspected. Original GUID/compute597 and structural audit1404/rootMD8 pass. Evidence P10-Rekey-checkpoint.json/-cause-summary.json/-evidence.zip/-files.json; prior full113 builds/checkpoint in -before.zip. Current Build-checkpoint fingerprints115+interactive2/API. P10 ACTIVE: next geometry Mesh identity/rebuild ownership; GPU stability/NonLocal attribution/physical Intel/XR and P11 configuration gaps remain open.

'''+s[at:];p.write_text(s)
Path('PORT_PROGRESS.md').write_text('''# Точка продолжения

Обновлено: **2026-11-05**. Цель Unity **6000.6.5f1 + URP17.6.0**, Windows DX11/DX12 Render Graph. Работать только в `outputs/Crest4-URP-Port`, branch `port/unity-6.6-urp`. Полный порт **не завершён**.

## Текущий этап: P10 ACTIVE

P00–P09 DONE в scoped-области PORT_PLAN; P11/P12 TODO. Единственный порядок задач — PORT_PLAN; результаты/ограничения — TEST_RESULTS/FEATURE_MATRIX. Не переоткрывать закрытый P09.

## Последний завершённый checkpoint

P10-Rekey scoped DONE: existing-target convergence терял10 native FFT textures; adaptation при frozen time возвращала старый spectrum output. Retired generators остаются owned до Ocean command submission/full cleanup; fast path требует initialized spectrum. Focused5/API/full115+actual interactive2/API, оба normal builds/4 smokes Passed. Target bytes/RT сохранены, старый consumer восстановлен точно, updated frozen output совпадает со fresh reference;16 queued EditMode layers корректны. Original runtime failure/queued before-control и2 setup failures архивированы отдельно. GUID/compute597, audit1404/rootMD8 pass. Активных операций нет.

Current normal fingerprints — Build-checkpoint.json, P10-Rekey-checkpoint.json; raw/source/5 actual Player+Editor DLLs — -evidence.zip/-files.json. Previous full113 bytes — -before.zip.28 capture frame pairs match, RenderData warnings0. Historical canonical fixture reports restored after verified archive; they are not current acceptance.

## Точное следующее действие

PORT_PLAN «Приёмка P10», пункт3 NEXT — geometry resource inventory. Прочитать OceanBuilder s_Meshes/GenerateMesh/CleanUp и OceanRenderer rebuild/cleanup, проверить existing tests перед новым запуском. Подготовить bounded native Mesh identity control create→geometry-density/LOD rebuild→destroy на обеих API, включая patch meshes без tile assignment, tile/root/proxy ownership. Сначала доказать actual lifetime; не менять geometry algorithms заранее. Не повторять принятые FFT, Calm, active-owner, GPU-counter capability и retention windows.

GPU timing attribution требует отдельного stable controlled window с focus/environment telemetry; наличие counters уже доказано. Driver NonLocal attribution/other configurations открыты. P11 combined Whirlpool damping, UnderwaterLighting fill0, остальные exact supported configurations и final acceptance остаются в плане.

## Сохраняемые изменения и ограничения

- Foreign Ocean.mat (4 serialization fields) и baked LightingData/ReflectionProbe folders BoatWakes/boat/threeboats/Examples/main/whirlpool не stage/reset/delete.
- Pre-existing dirty Buoyancy/ResourceLifecycle обоих API, focused DX11 XML и untracked FFT/leak-stack diagnostics не присваивать текущему изменению.
- Test-mutated TransparentPrimitive/OffWhite архивированы перед rebuild/восстановлены; variant whitespace архивируется отдельно. ProjectSettings без фактического diff.
- Historical evictable2490368B NOT REPRODUCED, owner не доказан/not fixed. DX11 NonLocal growth также в Empty; CPU Submit/engine inventories не GPU cost/physical VRAM. Intel/XR unavailable.
- No GenerateScenes, no upstream/historical diagnostic edits, no simultaneous Editors. Runtime change требует full/API, обоих builds/4 smokes; documentation-only не требует rebuild.

В корне8 обязательных Markdown. Не создавать новые status/progress/roadmap документы. Commit checkpoint — git log -1.
''')
