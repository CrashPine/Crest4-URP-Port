﻿from pathlib import Path
import subprocess,zipfile,json,hashlib
E=Path('Evidence');prefix='P10-Rekey-'
changed=subprocess.check_output(['git','diff','--name-only','--','Evidence'],text=True).splitlines()
foreign={'Evidence/Buoyancy-Direct3D11.txt','Evidence/Buoyancy-Direct3D12.txt','Evidence/ResourceLifecycle-Direct3D11.txt','Evidence/ResourceLifecycle-Direct3D12.txt','Evidence/EditMode-DX11-focused.xml'}
native=['Evidence/MaskedExamples-OpaqueMaskedGeometryReadsActualOceanMaskBeforeDepthAndColour-Direct3D11.txt','Evidence/MaskedExamples-OpaqueMaskedGeometryReadsActualOceanMaskBeforeDepthAndColour-Direct3D12.txt']
keep={'Evidence/Build-checkpoint.json','Evidence/workspace-audit.json',*native,*[f'Evidence/EditMode-{api}{suffix}.xml' for api in ['DX11','DX12'] for suffix in ['', '-interactive']]}
restore=[p for p in changed if p not in foreign|keep and not p.startswith('Evidence/Player-') and not Path(p).name.startswith(prefix)]
raw=[p for p in E.glob(prefix+'*') if p.suffix not in ['.zip'] and p.name not in [prefix+'cause-summary.json',prefix+'checkpoint.json',prefix+'files.json']]
logs=[E/f'{name}.log' for name in ['EditMode-DX11','EditMode-DX11-interactive','EditMode-DX12','EditMode-DX12-interactive','Development-DX11','Release-DX11']]
logs += [E/f'Player-{c}-{a}/Player.log' for c in ['Development','Release'] for a in ['DX11','DX12']]
sources=[Path(p) for p in subprocess.check_output(['git','ls-files','Assets/Crest/URP/Runtime/ResourceShutdownProbe*','Assets/Crest/URP/Editor/ResourceShutdownProbeBuild.cs','Assets/Crest/Crest/Scripts/Underwater/UnderwaterRenderer*','Assets/Crest/URP/Runtime/CrestBackgroundFeature.cs','Assets/Crest/URP/Runtime/PortDemoController*','Assets/Crest/Crest/Scripts/LodData/Shadows/LodDataMgrShadow.URP.cs','Assets/Crest/Crest/Scripts/OceanRenderer.cs','Tools/Run-Player.ps1','Assets/Crest/Crest/Scripts/Shapes/FFT/FFTCompute.cs','Assets/Crest/Crest/Scripts/Shapes/ShapeWaves.cs','Assets/Crest/Crest/Scripts/Shapes/FFT/ShapeFFT.cs','Assets/Crest/Crest/Scripts/Shapes/ShapeGerstner.cs','Assets/Crest/URP/Tests/Editor/FFTCacheLifetimeTests.cs'],text=True).splitlines()]
sources += [Path('Assets/Crest/URP/Tests/Editor/FFTCacheLifetimeTests.cs'),Path('Assets/Crest/URP/Tests/Editor/FFTCacheLifetimeTests.cs.meta')]
sources += [Path('Evidence/P10-FFTCache-Direct3D11.txt'),Path('Evidence/P10-FFTCache-Direct3D12.txt')]
sources += list(E.glob('P10-MixedWaves-*-Direct3D*.txt'))
assembly=list(Path('Builds/Development/CrestPort_Data/Managed').glob('Crest*.dll'))
assert len(assembly)==3
assembly += [Path('Library/ScriptAssemblies/Crest.dll'),Path('Library/ScriptAssemblies/Crest.URP.Tests.dll')]
files=sorted(set([Path(p) for p in restore]+raw+logs+sources+assembly+[Path(p) for p in native]))
archive=E/(prefix+'evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
 manifest=[dict(path=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest().upper(),bytes=p.stat().st_size) for p in files]
with zipfile.ZipFile(archive) as z:
 for a in manifest:assert hashlib.sha256(z.read(a['path'])).hexdigest().upper()==a['sha256']
for p in restore:Path(p).write_bytes(subprocess.check_output(['git','show','HEAD:'+p]))
# Raw duplicates remain recoverable by exact hash in the verified archive.
for p in raw:p.unlink()
for p in sources:
 if p.parent==E and (p.name.startswith('P10-FFTCache-') or p.name.startswith('P10-MixedWaves-')):p.unlink()
(E/(prefix+'files.json')).write_text(json.dumps(dict(archive=archive.as_posix(),sha256=hashlib.sha256(archive.read_bytes()).hexdigest().upper(),entries=manifest,restoredHistoricalPaths=restore),indent=2)+'\n',encoding='utf-8')
print(f'Archived {len(files)} files; restored {len(restore)} historical reports; preserved foreign changes')
