// Crest Ocean System. MIT; see LICENSE.
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.RenderGraphModule;
using UnityEngine.Rendering.Universal;

namespace Crest
{
    public partial class LodDataMgrShadow
    {
        #if CREST_SHADOW_ORDER_PROBE
        public static int DiagnosticTraceFrame = -1;
        void TraceOrder(string stage)
        {
            if (DiagnosticTraceFrame != Time.frameCount) return;
            Debug.Log($"SHADOW_ORDER {stage} frame={Time.frameCount} current={_ocean._lodTransform._renderData[0].Current._frame} previous={_ocean._lodTransform._renderData[0].Previous(1)._frame} owner={_ocean.GetEntityId()} singleton={OceanRenderer.Instance.GetEntityId()}");
        }
#endif
        readonly RTHandle[] _urpHandles = new RTHandle[4];
        sealed class ShadowPassData
        {
            public LodDataMgrShadow Owner;
            public Matrix4x4 View, Projection;
            public Rect Viewport;
        }

        TextureHandle Import(RenderGraph graph, int slot, RenderTexture texture)
        {
            if (_urpHandles[slot] == null || _urpHandles[slot].rt != texture)
            {
                _urpHandles[slot]?.Release();
                _urpHandles[slot] = RTHandles.Alloc(texture);
            }
            return graph.ImportTexture(_urpHandles[slot]);
        }

        void ReleaseUrpHandles()
        {
            for (int i = 0; i < _urpHandles.Length; i++)
            {
                _urpHandles[i]?.Release();
                _urpHandles[i] = null;
            }
        }

        public void RecordUrpShadows(RenderGraph graph, ContextContainer frameData)
        {
            #if CREST_SHADOW_ORDER_PROBE
            TraceOrder("record");
#endif
            var cameraData = frameData.Get<UniversalCameraData>();
            var camera = cameraData.camera;
            if (!enabled || !s_processData || BufCopyShadowMap == null || camera != _ocean.ViewCamera ||
                !Helpers.MaskIncludesLayer(camera.cullingMask, _ocean.Layer)) return;
            var lights = frameData.Get<UniversalLightData>();
            // Crest's primary light must match the atlas provided by URP for this camera.
            if (lights.mainLightIndex < 0 || lights.visibleLights[lights.mainLightIndex].light != _mainLight) return;
            var resources = frameData.Get<UniversalResourceData>();
            if (!resources.mainShadowsTexture.IsValid()) return;
            using var builder = graph.AddUnsafePass<ShadowPassData>("Crest: Temporal shadow accumulation", out var data);
            data.Owner = this;
            data.View = cameraData.GetViewMatrix();
            data.Projection = cameraData.GetProjectionMatrix();
            data.Viewport = camera.pixelRect;
            builder.UseTexture(resources.mainShadowsTexture, AccessFlags.Read);
            builder.UseTexture(Import(graph, 0, _targets.Current), AccessFlags.ReadWrite);
            builder.UseTexture(Import(graph, 1, _targets.Previous(1)), AccessFlags.Read);
            if (_ocean._lodDataAnimWaves != null)
                builder.UseTexture(Import(graph, 2, _ocean._lodDataAnimWaves.DataTexture), AccessFlags.Read);
            if (_ocean._lodDataSeaDepths != null)
                builder.UseTexture(Import(graph, 3, _ocean._lodDataSeaDepths.DataTexture), AccessFlags.Read);
            builder.UseAllGlobalTextures(true);
            builder.AllowGlobalStateModification(true);
            builder.AllowPassCulling(false);
            builder.SetRenderFunc((ShadowPassData pass, UnsafeGraphContext context) =>
            {
                #if CREST_SHADOW_ORDER_PROBE
                pass.Owner.TraceOrder("execute");
#endif
                var cmd = CommandBufferHelpers.GetNativeCommandBuffer(context.cmd);
                var camera = pass.Owner._ocean.ViewCamera;
                bool stereo = camera.stereoEnabled && XRHelpers.IsSinglePass;
                if (stereo) cmd.DisableShaderKeyword("STEREO_INSTANCING_ON");
                pass.Owner.BuildCommandBuffer(pass.Owner._ocean, cmd);
                // Registered LOD inputs install orthographic simulation matrices. URP does
                // not restore those after an unsafe custom pass as the Built-in light pass did.
                cmd.SetViewProjectionMatrices(pass.View, pass.Projection);
                cmd.SetViewport(pass.Viewport);
                if (stereo) cmd.EnableShaderKeyword("STEREO_INSTANCING_ON");
            });
        }
    }
}
