$ErrorActionPreference='Stop'
$p=Start-Process 'C:/Program Files/Unity/Hub/Editor/6000.6.5f1/Editor/Unity.exe' -WindowStyle Hidden -ArgumentList '-batchmode','-quit','-projectPath',('"'+(Get-Location).Path+'"'),'-force-d3d11','-executeMethod','Crest.URP.Editor.ResourceShutdownProbeBuild.Build','-logFile',('"'+(Join-Path (Get-Location) 'Evidence/P10-StableGpu-build.log')+'"') -Wait -PassThru
if($p.ExitCode -ne 0){throw "Diagnostic build exit $($p.ExitCode)"}
