from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime
E=Path('Evidence');summary=E/'P10-StableGpu-summary.json';x=json.loads(summary.read_text());cp=E/'Build-checkpoint.json';normal=json.loads(cp.read_text(encoding='utf-8-sig'))
assert cp.read_bytes().replace(b'\r\n',b'\n')==subprocess.check_output(['git','show','HEAD:'+cp.as_posix()]).replace(b'\r\n',b'\n')
for item in x['protocol']['normalArtifactsBefore']:assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest().upper()==item['sha256']
for item in normal['runtimeSources']+normal['materialSources']:assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest().upper()==item['sha256'],item['path']
assert len(x['results'])==2 and all(not r['attributionAccepted'] for r in x['results'])
for api in ['DX11','DX12']:
 r=json.loads((E/f'P10-StableGpu-{api}.json').read_text());assert r['errors']==0 and len(r['phases'])==3
 assert sum(len(p['samples']) for p in r['phases'])>=1790
x.update(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),validation='Bounded measurements complete; isolated GPU attribution REJECTED on both APIs by original gates',normalArtifactsVerified=12,normalRuntimeAndMaterialSourcesVerified=True,normalCheckpointContentUnchangedAfterEOLNormalization=True,normalBuildCheckpointSHA256=hashlib.sha256(cp.read_bytes()).hexdigest().upper(),originalPreservation=json.loads((E/'P10-StableGpu-source-check.json').read_text(encoding='utf-8-sig')),criticalWarnings=json.loads((E/'P10-StableGpu-warning-check.json').read_text()))
a=E/'workspace-audit.json';audit=json.loads(a.read_text(encoding='utf-8-sig'));assert audit['fileCount']==1405 and not any(audit[k] for k in ['missingAssetMeta','duplicateGuids','missingOriginalFiles']);assert len(list(Path('.').glob('*.md')))==8
x['workspaceAudit']={'path':a.as_posix(),'sha256':hashlib.sha256(a.read_bytes()).hexdigest().upper(),'fileCount':1405,'rootMarkdownCount':8}
summary.write_text(json.dumps(x,indent=2)+'\n')
raw=[p for p in E.glob('P10-StableGpu-*') if p.suffix!='.zip' and p.name not in ['P10-StableGpu-summary.json','P10-StableGpu-files.json']]
sources=[Path(n) for n in ['Assets/Crest/URP/Runtime/ResourceShutdownProbe.cs','Assets/Crest/URP/Runtime/ResourceShutdownProbe.Profile.cs','Assets/Crest/URP/Editor/ResourceShutdownProbeBuild.cs','Tools/Run-StableGpuWindow.ps1','Assets/Crest/Crest-Examples/Whirlpool/Scripts/Whirlpool.cs','Assets/Crest/Crest/Shaders/OceanInputs/Resources/DynWavesDampenCircle.shader','Assets/Crest/URP/Tests/Editor/RippleGeneratorTests.cs','Assets/Crest/URP/Tests/Editor/OriginalWhirlpoolTests.cs']]
assemblies=list(Path('Builds/P10-ResourceProbe/ResourceProbe_Data/Managed').glob('Crest*.dll'));assert len(assemblies)==3
files=sorted(set(raw+sources+assemblies));archive=E/'P10-StableGpu-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
manifest=[{'path':p.as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest().upper(),'bytes':p.stat().st_size} for p in files]
with zipfile.ZipFile(archive) as z:
 for f in manifest:assert hashlib.sha256(z.read(f['path'])).hexdigest().upper()==f['sha256']
(E/'P10-StableGpu-files.json').write_text(json.dumps({'archive':archive.as_posix(),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest().upper(),'entries':manifest},indent=2)+'\n')
for p in raw:p.unlink()
print('Archived/verified',len(files),'files; normal sources/artifacts unchanged; both attribution rejections retained')
