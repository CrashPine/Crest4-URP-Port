from pathlib import Path
import json,csv,datetime,statistics,hashlib
E=Path('Evidence');protocol=json.loads((E/'P10-StableGpu-protocol.json').read_text());g=protocol['gates']
med=statistics.median
def num(value):
 try:return float(value.split()[0])
 except ValueError:return None
results=[]
for api in ['DX11','DX12']:
 p=E/f'P10-StableGpu-{api}.json'
 if not p.exists():continue
 x=json.loads(p.read_text());assert x['unity']=='6000.6.5f1' and x['errors']==0 and x['api']=='Direct3D'+api[2:]
 with (E/f'P10-StableGpu-{api}-telemetry.csv').open() as f:
  rows=[{k.strip():v.strip() for k,v in r.items()} for r in csv.DictReader(f)]
 telemetry=[]
 for r in rows:
  if r['name']!=x['gpu']:continue
  t=datetime.datetime.strptime(r['timestamp'],'%Y/%m/%d %H:%M:%S.%f').astimezone().timestamp()
  telemetry.append(dict(t=t,clock=num(r['clocks.current.graphics [MHz]']),temperature=num(r['temperature.gpu']),load=num(r['utilization.gpu [%]']),power=num(r['power.draw [W]'])))
 phases=[]
 for phase in x['phases']:
  samples=phase['samples'];gpu=[s['gpuMs'] for s in samples if s['freshTiming'] and s['gpuMs']>0];tel=[r for r in telemetry if phase['startUnixSeconds']<=r['t']<=phase['endUnixSeconds'] and r['clock'] is not None and r['temperature'] is not None]
  assert tel,'No synchronized GPU telemetry'
  phaseResult=dict(name=phase['name'],samples=len(samples),focusedFraction=sum(s['focused'] for s in samples)/len(samples),freshPositiveGpuFraction=len(gpu)/len(samples),renderSampleMismatch=abs(samples[-1]['renders']-samples[0]['renders']-(len(samples)-1)),gpuMedianMs=med(gpu) if gpu else None,gpuP95Ms=sorted(gpu)[int(.95*(len(gpu)-1))] if gpu else None,counterMedians=[med(s['counters'][i] for s in samples) for i in range(len(x['counters']))],clockMedianMHz=med(r['clock'] for r in tel),clockRangeMHz=[min(r['clock'] for r in tel),max(r['clock'] for r in tel)],temperatureMedianC=med(r['temperature'] for r in tel),telemetrySamples=len(tel),loadKnownSamples=sum(r['load'] is not None for r in tel),powerKnownSamples=sum(r['power'] is not None for r in tel),loadMedianPercent=med(r['load'] for r in tel if r['load'] is not None) if any(r['load'] is not None for r in tel) else None,powerMedianW=med(r['power'] for r in tel if r['power'] is not None) if any(r['power'] is not None for r in tel) else None)
  phaseResult['sampleGates']=all([len(samples)>=g['samplesPerPhaseMin'],phaseResult['focusedFraction']>=g['focusedFractionMin'],phaseResult['freshPositiveGpuFraction']>=g['positiveUniqueGpuFractionMin'],phaseResult['renderSampleMismatch']<=g['renderSampleMismatchMax'],phase['width']==960,phase['height']==540])
  phases.append(phaseResult)
 a,b,c=phases;drift=abs(c['gpuMedianMs']-a['gpuMedianMs'])/a['gpuMedianMs'] if a['gpuMedianMs'] and c['gpuMedianMs'] else None
 clocks=[r['clockMedianMHz'] for r in phases];spread=(max(clocks)-min(clocks))/min(clocks)
 drawIndex=next(i for i,d in enumerate(x['counters']) if d['name']=='Draw Calls Count');draws=[r['counterMedians'][drawIndex] for r in phases]
 gates=dict(samples=all(r['sampleGates'] for r in phases),baselineDrift=drift is not None and drift<=g['baselineGpuMedianRelativeDriftMax'],graphicsClocks=spread<=g['allPhaseGraphicsClockMedianRelativeSpreadMax'],temperature=abs(c['temperatureMedianC']-a['temperatureMedianC'])<=g['baselineTemperatureMedianDeltaMaxC'],drawRestoration=draws[0]==draws[2] and draws[1]>draws[0])
 results.append(dict(api=api,phases=phases,baselineDriftFraction=drift,clockSpreadFraction=spread,drawMedians=draws,gates=gates,attributionAccepted=all(gates.values()),visibleSurfaceMedianDifferenceMs=b['gpuMedianMs']-(a['gpuMedianMs']+c['gpuMedianMs'])/2 if all(gates.values()) else None))
print(json.dumps(results,indent=2))
(E/'P10-StableGpu-summary.json').write_text(json.dumps(dict(protocol=protocol,results=results,limitation='One bounded frozen-Calm surface A-B-A/API, complete-frame observations; no full-asset GPU cost/API ranking/FPS/physical VRAM acceptance. Rejected gates retained.'),indent=2)+'\n')
