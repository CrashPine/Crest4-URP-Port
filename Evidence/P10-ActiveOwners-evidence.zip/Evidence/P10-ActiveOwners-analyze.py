from pathlib import Path
import json,hashlib,datetime,subprocess
E=Path('Evidence');cases=[]
for api in ['DX11','DX12']:
 p=E/f'P10-ActiveOwners-{api}.json';x=json.loads(p.read_text());assert x['errors']==0 and len(x['stages'])==8
 rows=[]
 for i in range(2):
  on,off,again,out=x['stages'][i*4:i*4+4]
  for s in [on,again]:
   assert s['foam'] and s['dynamicWaves'] and s['flow'] and s['activeFFTShapes']==1
   assert len(s['reachableBuffers'])==8 and sum(b['logicalBytes'] for b in s['reachableBuffers'])==198592
  assert not any(off[n] for n in ['foam','dynamicWaves','flow']) and off['activeFFTShapes']==0
  assert len(off['reachableBuffers'])==6 and sum(b['logicalBytes'] for b in off['reachableBuffers'])==100288
  for s in [on,off,again]:assert s['fftGenerators']==i+1
  def fft(s):return {t['id'] for t in s['trackedTextures'] if t['created'] and (t['name'].startswith('CrestFFT') or t['name']=='FFTCascades')}
  assert len(fft(on))==8 and fft(on)==fft(off)==fft(again)
  assert out['snapshot']['oceans']==0 and not out['reachableBuffers'] and not any(b['valid'] for b in out['trackedBufferState']) and not any(t['created'] for t in out['trackedTextures'])
  assert not any(t['alive'] for t in out['trackedTextures'])
  owned={k:[t for t in on['trackedTextures'] if k in t['owner'] and t['created']] for k in ['_lodDataFoam','_lodDataDynWaves','_lodDataFlow']}
  assert [len(owned[k]) for k in owned]==[3,3,1]
  for group in owned.values():
   ids={t['id'] for t in group};assert all(not t['created'] and not t['alive'] for t in off['trackedTextures'] if t['id'] in ids)
  rows.append(dict(cycle=i+1,liveBuffers=8,liveLogicalBytes=198592,disabledBuffers=6,disabledLogicalBytes=100288,fftRTsRetainedOnToggle=8,simulationRTsDestroyedOnToggle=7,unloadedBuffers=len(out['trackedBufferState']),unloadedValidBuffers=0,unloadedTrackedRTs=len(out['trackedTextures']),unloadedAliveRTs=0,snapshotRTs=len(out['snapshot']['textures']),fftManagedEntries=out['fftGenerators'],walkLimits=on['walkLimits']))
 log=p.with_suffix('.log').read_text(errors='replace');assert 'ACTIVE_OWNERS_COMPLETED errors=0' in log
 cases.append(dict(api=api,file=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),cycles=rows,warnings={k:log.count(k) for k in ['RenderData validation failed','evictable','Persistent allocates','temporary render texture','Shader error']}))
 print(api,rows)
normal=json.loads((E/'Build-checkpoint.json').read_text());hashes=[]
for group,key in [('builds','assembly'),('packedAssets','path')]:
 for a in normal[group]:
  p=Path('Builds')/a['configuration']/a[key];sha=hashlib.sha256(p.read_bytes()).hexdigest().upper();assert sha==a['sha256'];hashes.append(dict(path=p.as_posix(),sha256=sha))
p=Path('Assets/Crest/Crest/Scripts/Shapes/FFT/FFTCompute.cs');up=Path('../../work/crest-upstream/crest/Assets/Crest/Crest/Scripts/Shapes/FFT/FFTCompute.cs');same=p.read_text(encoding='utf-8-sig')==up.read_text(encoding='utf-8-sig')
(E/'P10-ActiveOwners-summary.json').write_text(json.dumps(dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),validation='PASSED scoped native owner lifecycle',cases=cases,normalBuildsUnchanged=hashes,fftComputeSourceSameAsUpstream=same,managedCacheObservation='Generator entries1->2 retained after native cleanup across two loads; no native retention in tracked fields. Managed cache policy needs separate investigation, not a proven VRAM leak.',limitation='Diagnostic Flow enabled via original private flag; scene assets unchanged. Actual query recovery before snapshots;8 FFT RTs reused on input toggle,7 simulation RTs destroyed, native buffer reinitialization observed on settings transitions. Only owner-reachable RT/ComputeBuffer graph, query-position array truncation disclosed; no general driver/mesh/VRAM acceptance.'),indent=2)+'\n')
