$ErrorActionPreference='Stop'
$root=(Get-Location).Path
foreach($api in @('DX11','DX12')){
 $name="P10-ActiveOwners-$api";$start=[DateTime]::UtcNow
 [ordered]@{step=$name;status='RUNNING';startUtc=$start.ToString('o')} | ConvertTo-Json | Set-Content Evidence/P10-ActiveOwners-operation.json
 $taskArgs=@('-batchmode','-screen-width','960','-screen-height','540','-crestResourceProbe','-crestProbeMode','Ocean','-crestProbeScene','2','-crestActiveOwners','-crestProbeOutput',('"'+(Join-Path $root "Evidence/$name.json")+'"'),'-logFile',('"'+(Join-Path $root "Evidence/$name.log")+'"'))
 $taskArgs+=$(if($api -eq 'DX11'){'-force-d3d11'}else{'-force-d3d12'})
 $p=Start-Process (Join-Path $root 'Builds/P10-ResourceProbe/ResourceProbe.exe') -ArgumentList $taskArgs -WindowStyle Hidden -PassThru
 if(!$p.WaitForExit(120000)){Stop-Process -Id $p.Id;throw 'Active owner timeout'}
 if($p.ExitCode -ne 0){throw "Active owner exit $($p.ExitCode)"}
 $file=Get-Item "Evidence/$name.json";if($file.LastWriteTimeUtc -lt $start){throw 'Stale owner report'}
 $report=Get-Content $file.FullName -Raw | ConvertFrom-Json
 if($report.errors -ne 0 -or $report.stages.Count -ne 8){throw 'Owner control failed'}
 [ordered]@{step=$name;status='PASSED';endUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress | Add-Content Evidence/P10-ActiveOwners-completions.jsonl
}
