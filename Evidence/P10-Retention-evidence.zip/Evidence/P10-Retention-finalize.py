﻿from pathlib import Path
import json,zipfile,hashlib,subprocess,datetime
E=Path('Evidence');prefix='P10-Retention-'
x=json.loads((E/(prefix+'summary.json')).read_text());assert len(x['cases'])==4
assert len((E/(prefix+'completions.jsonl')).read_text().splitlines())==4
for c in x['cases']:
 print(c['api'],c['mode'],c['shutdownWarnings'],c['shadowWarnings'])
x['validation']='PASSED (bounded diagnostic, not full lifetime acceptance)'
x['normalBuildsUnchanged']=json.loads((E/(prefix+'normal-build-hashes.json')).read_text())
x['conclusion']='DX11 Ocean Local accounting is exactly flat over cycles6-10 and final idle; NonLocal continues small growth, also seen in Empty control. DX12 unloaded accounting is stable from cycle2 onward. Sixty observed Ocean buffer wrappers/API invalid after unload, RT inventories stable. No proof of exact native allocator/physical residency or general leak freedom; no disposal fix claimed.'
(E/(prefix+'summary.json')).write_text(json.dumps(x,indent=2)+'\n')
p=Path('TEST_RESULTS.md');s=p.read_text(encoding='utf-8');marker='## P10: repeated underwater classification cached'
rows=[]
for c in x['cases']:
 r=c['cycles'];rows.append(f"|{c['api']} {c['mode']}|{r[0]['local5s']/1048576:.4f} → {r[-1]['local5s']/1048576:.4f}|{r[0]['nonLocal5s']/1048576:.4f} → {r[-1]['nonLocal5s']/1048576:.4f}|{c['finalLocal']/1048576:.4f} / {c['finalNonLocal']/1048576:.4f}|{c['finalRT']}|")
block='''## P10: bounded10-cycle driver retention controls (2026-11-04)

Diagnostic-only extension of the existing ownership probe:10 cycles per Empty/Ocean xDX11/DX12, one960x540 ARGB32/depth24 Submit and1x1 async readback,2s live hold, actual scene reload/unload and UnloadUnusedAssets. Unloaded observations at2s and5s, then final additional5s/15s idle after the last cycle. Realtime timestamps validate waits. Empty disables Crest feature and reloads the same control scene with matching cycle/cleanup count. All4 runs exit0/errors0 with fresh completion reports; every DXGI adapter/segment query succeeds. No images or full-suite/default rebuild repeated for this conditional diagnostic change.

| API / scene | Local first→last5s MiB | NonLocal first→last5s MiB | Final Local / NonLocal MiB | Unloaded RT |
|---|---:|---:|---:|---:|
'''+ '\n'.join(rows)+'''

DX11 Ocean Local is exactly161.41796875MiB at cycles6–10 and after final idle. NonLocal remains slowly growing (17.3203→18.7031MiB), whereas Empty also grows (4.9180→5.5469, final6.421875). Thus indefinite per-cycle Local growth is not observed in this bounded window; retained Local does not return to Empty levels, and NonLocal growth cannot be wholly attributed to Crest. DX12 unloaded accounting is stable from cycle2 onward. This is not an API performance ranking, leak-free proof or exact physical Crest VRAM measurement. Driver/cache/engine/diagnostic contribution to NonLocal remains unresolved; no allocator/disposal fix inferred.

All10 live Ocean cycles/API have six valid ComputeBuffers/100288 logical bytes; all60 wrappers invalid after final unload, zero reachable buffers/oceans. Unloaded RT counts8 Ocean/6 Empty remain constant. Raw owner paths/descriptors and walker truncation limits retained; inactive subsystems/native mesh/driver graphs not covered. Known evictable/Persistent/temporary-RT shutdown warnings absent in accepted runs. Normal12 binary/packed fingerprints match Build-checkpoint; ordinary runtime is unchanged because the entire modified file is conditional on CREST_RESOURCE_PROBE. Previous8de101d full110+interactive2/API/default builds/four smokes remain their checkpoint. Serialization whitespace archived/restored, foreign Ocean/bakes untouched. Evidence P10-Retention-summary.json and -evidence.zip/-files.json. Next: causal Shadow RenderData frame-order investigation; P10/P11/P12 incomplete.

'''
s=s.replace(marker,block+marker,1);p.write_text(s,encoding='utf-8')
p=Path('PORT_PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('Next bounded DX11 retention/reclaim investigation, then remaining variants/resources/GPU-draw gaps.','Bounded10-cycle Empty/Ocean controls/API complete: late Local plateau, NonLocal attribution unresolved. Next Shadow frame-order cause, then remaining variants/resources/GPU-draw gaps.');a=s.index('2. **NEXT — DX11 driver retention:**');b=s.index('\n3. **TODO — remaining P10 acceptance:**',a)
s=s[:a]+'''2. **DONE (bounded scope) — driver retention window:** Empty/Ocean10 cycles each API with2s/5s unloaded checkpoints and final additional15s idle; all4 pass. DX11 Ocean Local exactly flat cycles6–10/final; small NonLocal growth also in Empty, attribution unresolved. DX12 unloaded values stable from cycle2 onward. All60 Ocean buffers/API invalid, RT inventories stable. Evidence P10-Retention-summary.json; no general leak-free/physical VRAM acceptance. Do not repeat these four windows without a new causal hypothesis.
'''.rstrip()+s[b:]
s=s.replace('Track existing Player Shadow RenderData frame-validation warnings (also present before this fix); resolve render/update order with causal evidence rather than suppressing validation.','**NEXT: Shadow RenderData frame-order cause.** Instrument scene-transition first render versus OceanRenderer/LodTransform update and shadow Record/Execute frame IDs; reproduce the existing14 warnings/Player, build a focused order/restoration control before changing runtime. Do not suppress validation. Keep unproven NonLocal attribution and remaining resource owners explicit.')
s=s.replace('Latest previous full90 is historical until a fresh run actually completes.','Current scoped checkpoint8de101d has110+interactive2/API and rebuilt Players; it does not replace the remaining P11 configuration/final acceptance.')
p.write_text(s,encoding='utf-8')
p=Path('FEATURE_MATRIX.md');s=p.read_text(encoding='utf-8').replace('DX11 retained/growing driver usage unresolved.','Bounded10-cycle controls/API: DX11 Local late plateau, small NonLocal growth also in Empty; DX12 stable unloaded from cycle2 onward. All60 Ocean buffers/API invalid, RT inventories stable; NonLocal owner/physical residency unresolved.');p.write_text(s,encoding='utf-8')
p=Path('PORT_PROGRESS.md');s=p.read_text(encoding='utf-8');a=s.index('Активная работа:');b=s.index(' GPU classification cache',a)
s=s[:a]+'Активных Unity/Player операций нет. Новый diagnostic-only checkpoint P10-Retention:4 accepted10-cycle controls, all errors0; DX11 Local late plateau, NonLocal attribution unresolved; DX12 stable unloaded from cycle2 onward. All60 observed Ocean buffers/API disposed, RT inventories stable. Raw/source/assembly and commands hash-indexed in P10-Retention-evidence.zip/-files.json; summary in -summary.json. Normal12 build hashes unchanged; no ordinary runtime change.'+s[b:]
a=s.index('Следовать PORT_PLAN разделу');b=s.index('\n\nОтдельно остаются',a)
s=s[:a]+'''Следовать PORT_PLAN разделу «Приёмка P10 — оставшаяся последовательность», пункт3 NEXT: причинная проверка Shadow RenderData frame-order. Прочитать LodDataMgrShadow.URP.cs Record/Execute и LodDataMgr.SubmitDraws/LodTransform.RenderData.Validate; сопоставить первые scene-transition renders с OceanRenderer update. Diagnostic trace должен различать rendering до обновления, дублированное обновление и stale-owner state. Сохранить14 warnings/API baseline, затем focused order/restoration control; не подавлять warning и не менять simulation/compute алгоритмы. P10 ownership10-cycle windows закрыты только в измеренной области, не повторять их без новой причинной гипотезы. NonLocal attribution остаётся нерешённой; не заявлять leak-free/точный VRAM.'''+s[b:]
p.write_text(s,encoding='utf-8')
print('Updated existing four documents with bounded results/next causal task')
