param([string]$API='DX11')
$ErrorActionPreference='Stop'
$root=(Get-Location).Path
foreach($mode in @('Empty','Ocean')){
 $name="P10-Retention-$mode-$API"
 $started=[DateTime]::UtcNow
 [ordered]@{step=$name;startUtc=$started.ToString('o');status='RUNNING'} | ConvertTo-Json | Set-Content "Evidence/P10-Retention-operation.json"
 $argsList=@('-batchmode','-screen-width','960','-screen-height','540','-crestResourceProbe','-crestProbeMode',$mode,'-crestOwnership','-crestOwnershipReadback','Crop','-crestOwnershipCycles','10','-crestProbeOutput',('"'+(Join-Path $root "Evidence/$name.json")+'"'),'-logFile',('"'+(Join-Path $root "Evidence/$name.log")+'"'))
 $argsList+=$(if($API -eq 'DX11'){'-force-d3d11'}else{'-force-d3d12'})
 if($mode -eq 'Empty'){$argsList+='-crestProbeDisableFeature'}
 $player=Start-Process (Join-Path $root 'Builds/P10-ResourceProbe/ResourceProbe.exe') -ArgumentList $argsList -WindowStyle Hidden -PassThru -Wait
 if($player.ExitCode -ne 0){throw "$name failed exit $($player.ExitCode)"}
 $report=Get-Item "Evidence/$name.json"
 if($report.LastWriteTimeUtc -lt $started){throw 'Stale report'}
 $result=Get-Content $report.FullName -Raw | ConvertFrom-Json
 if($result.errors -ne 0 -or $result.cycles -ne 10 -or !$result.extendedIdle){throw 'Invalid report'}
 [ordered]@{step=$name;startUtc=$started.ToString('o');endUtc=[DateTime]::UtcNow.ToString('o');status='PASSED'} | ConvertTo-Json -Compress | Add-Content 'Evidence/P10-Retention-completions.jsonl'
}
