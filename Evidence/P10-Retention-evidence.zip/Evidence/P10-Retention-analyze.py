from pathlib import Path
import json,hashlib,datetime
cases=[]
for api in ['DX11','DX12']:
 for mode in ['Empty','Ocean']:
  p=Path(f'Evidence/P10-Retention-{mode}-{api}.json')
  if not p.exists():continue
  x=json.loads(p.read_text());assert x['errors']==0 and x['cycles']==10 and x['extendedIdle'] and x['readback']=='Crop' and x['hdr']
  assert x['api']==('Direct3D11' if api=='DX11' else 'Direct3D12') and x['featureDisabled']==(mode=='Empty')
  ss={s['stage']:s for s in x['stages']}
  for s in x['stages']:
   d=s['driverMemory'];assert d['status']=='ok' and d['localHresult']==d['nonLocalHresult']==0 and d['vendor']==0x10de and d['device']==0x25a0
  rows=[]
  for i in range(10):
   pre=f'cycle{i}-';live=ss[pre+'held'];u=ss[pre+'ocean-unloaded'];a=ss[pre+'unloaded-held'];b=ss[pre+'unloaded-idle5s']
   assert u['snapshot']['oceans']==0 and not any(v['valid'] for v in u['trackedBufferState']) and not u['reachableBuffers']
   assert a['realtime']-u['realtime']>=1.95 and b['realtime']-a['realtime']>=2.95
   if mode=='Ocean':assert len(live['reachableBuffers'])==6 and sum(v['logicalBytes'] for v in live['reachableBuffers'])==100288
   rows.append(dict(cycle=i+1,liveRT=len(live['snapshot']['textures']),unloadedRT=len(b['snapshot']['textures']),tracked=len(b['trackedBufferState']),valid=sum(v['valid'] for v in b['trackedBufferState']),local2s=a['driverMemory']['local']['currentUsage'],nonLocal2s=a['driverMemory']['nonLocal']['currentUsage'],local5s=b['driverMemory']['local']['currentUsage'],nonLocal5s=b['driverMemory']['nonLocal']['currentUsage']))
  f=ss['final-idle15s'];assert f['realtime']-ss['final-idle5s']['realtime']>=9.95
  assert not any(v['valid'] for v in f['trackedBufferState']) and f['snapshot']['oceans']==0
  log=p.with_suffix('.log').read_text(errors='replace');assert f'OWNERSHIP_PROBE_COMPLETED {mode} Crop errors=0' in log
  cases.append(dict(file=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),api=api,mode=mode,cycles=rows,finalLocal=f['driverMemory']['local']['currentUsage'],finalNonLocal=f['driverMemory']['nonLocal']['currentUsage'],finalRT=len(f['snapshot']['textures']),tracked=len(f['trackedBufferState']),shadowWarnings=log.count('RenderData validation failed'),shutdownWarnings={k:log.count(k) for k in ['evictable','Persistent allocates','temporary render texture']}))
  print(api,mode,'Local5s MiB',[round(r['local5s']/1048576,4) for r in rows],'NonLocal5s MiB',[round(r['nonLocal5s']/1048576,4) for r in rows],'final',f['driverMemory']['local']['currentUsage']/1048576,f['driverMemory']['nonLocal']['currentUsage']/1048576,'RT',[r['unloadedRT'] for r in rows])
Path('Evidence/P10-Retention-summary.json').write_text(json.dumps(dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=cases,limitation='Process DXGI accounting, not exact physical Crest VRAM; single short-window run per control; known walker limits retained in raw data.'),indent=2)+'\n')
