// Builds an isolated diagnostic Player without replacing deliverable builds. MIT.
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace Crest.URP.Editor
{
    public static class ResourceShutdownProbeBuild
    {
        public static void Build() => BuildImpl(0);
        public static void BuildOriginalExamples() => BuildImpl(1);
        public static void BuildOriginalScenes() => BuildImpl(2);
        public static void BuildRenderModes() => BuildImpl(3);
        public static void BuildCameraStack() => BuildImpl(4);
        public static void BuildReflectionModes() => BuildImpl(5);
        static void BuildImpl(int mode)
        {
            if (Application.unityVersion != "6000.6.5f1") throw new InvalidOperationException("Wrong Unity target.");
            var qualityPipeline=QualitySettings.renderPipeline;
            var preloadedAssets=PlayerSettings.GetPreloadedAssets();
            bool timing=PlayerSettings.enableFrameTimingStats;
            bool strict=PlayerSettings.strictShaderVariantMatching;
            const string parent="Assets";
            string folder=parent+"/CrestResourceProbe_"+Guid.NewGuid().ToString("N");
            string guid=AssetDatabase.CreateFolder(parent, Path.GetFileName(folder));
            try
            {
                var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                var camera=new GameObject("Main Camera", typeof(Camera)).GetComponent<Camera>();
                camera.tag="MainCamera";
                camera.backgroundColor=Color.gray;
                camera.clearFlags=CameraClearFlags.SolidColor;
                camera.GetUniversalAdditionalCameraData().requiresDepthTexture=true;
                // Cost probes enable this exact Calm variant at runtime. Retain it by a
                // serialized dependency; strict shader matching must remain enabled.
                var underwater=new Material(AssetDatabase.LoadAssetAtPath<Material>("Assets/CrestPortDemos/Ocean_Calm.mat"));
                underwater.EnableKeyword("_UNDERWATER_ON");underwater.SetFloat("_Underwater",1);
                AssetDatabase.CreateAsset(underwater,folder+"/DiagnosticUnderwater.mat");
                var retention=new GameObject("Diagnostic shader variant dependency",typeof(MeshRenderer)).GetComponent<MeshRenderer>();
                retention.enabled=false;retention.sharedMaterial=underwater;
                var planar=new Material(AssetDatabase.LoadAssetAtPath<Material>("Assets/CrestPortDemos/Ocean_Calm.mat"));
                planar.EnableKeyword("_PLANARREFLECTIONS_ON");
                AssetDatabase.CreateAsset(planar,folder+"/DiagnosticPlanar.mat");
                var counterControl=new Material(Shader.Find("Universal Render Pipeline/Unlit"));
                AssetDatabase.CreateAsset(counterControl,folder+"/DiagnosticCounterControl.mat");
                retention.sharedMaterials=new[]{underwater,planar,counterControl};
                if(mode==4)
                {
                    var flat=new Material(underwater);flat.DisableKeyword("_TRANSPARENCY_ON");flat.DisableKeyword("_APPLYNORMALMAPPING_ON");flat.SetFloat("_Transparency",0);
                    AssetDatabase.CreateAsset(flat,folder+"/StackFlatUnderwater.mat");
                    var flatAbove=new Material(flat);flatAbove.DisableKeyword("_UNDERWATER_ON");flatAbove.SetFloat("_Underwater",0);
                    AssetDatabase.CreateAsset(flatAbove,folder+"/StackFlatAbove.mat");
                    var foam=new Material(Shader.Find("Crest/Inputs/Foam/Override Foam"));AssetDatabase.CreateAsset(foam,folder+"/StackFoamSeed.mat");
                    retention.sharedMaterials=new[]{underwater,planar,counterControl,flat,flatAbove,foam};
                }
                if(mode==5)
                {
                    var original=AssetDatabase.LoadAssetAtPath<UniversalRendererData>("Assets/CrestPortDemos/Renderer.asset");
                    var forward=UnityEngine.Object.Instantiate(original);forward.renderingMode=RenderingMode.Forward;AssetDatabase.CreateAsset(forward,folder+"/Forward.asset");
                    var clustered=UnityEngine.Object.Instantiate(original);clustered.renderingMode=RenderingMode.ForwardPlus;AssetDatabase.CreateAsset(clustered,folder+"/ForwardPlus.asset");
                    var deferred=UnityEngine.Object.Instantiate(original);deferred.renderingMode=RenderingMode.Deferred;AssetDatabase.CreateAsset(deferred,folder+"/Deferred.asset");
                    var pipeline=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>("Assets/CrestPortDemos/Pipeline.asset"));
                    var serialized=new SerializedObject(pipeline);var renderers=serialized.FindProperty("m_RendererDataList");renderers.arraySize=3;
                    renderers.GetArrayElementAtIndex(0).objectReferenceValue=forward;renderers.GetArrayElementAtIndex(1).objectReferenceValue=clustered;renderers.GetArrayElementAtIndex(2).objectReferenceValue=deferred;
                    serialized.ApplyModifiedPropertiesWithoutUndo();AssetDatabase.CreateAsset(pipeline,folder+"/ReflectionModesPipeline.asset");
                    // Build against this owned pipeline so native URP stripping sees all three
                    // renderer modes; source pipeline and source quality exclusions are preserved.
                    QualitySettings.renderPipeline=pipeline;AssetDatabase.SaveAssets();
                }
                string path=folder+"/Resource_Control.unity";
                EditorSceneManager.SaveScene(scene,path);
                PlayerSettings.enableFrameTimingStats=true;
                if(mode != 0)PlayerSettings.strictShaderVariantMatching=true;
                var build=BuildPipeline.BuildPlayer(new BuildPlayerOptions {
                    scenes=mode==5?new[]{path,"Assets/CrestPortDemos/Ocean_Reflections.unity"}:mode==4?new[]{path,"Assets/CrestPortDemos/Ocean_Calm.unity"}:mode==3?new[]{path,"Assets/CrestPortDemos/Ocean_Underwater.unity"}:mode==2?new[]{path,
                        "Assets/Crest/Crest-Examples/Main/Scenes/main.unity",
                        "Assets/Crest/Crest-Examples/BoatDev/Scenes/boat.unity",
                        "Assets/Crest/Crest-Examples/BoatDev/Scenes/BoatWakes.unity",
                        "Assets/Crest/Crest-Examples/BoatDev/Scenes/threeboats.unity",
                        "Assets/Crest/Crest-Examples/LakesAndRivers/Scenes/LakesAndRivers.unity",
                        "Assets/Crest/Crest-Examples/Whirlpool/Scenes/whirlpool.unity"}:
                        mode==1?new[]{path,"Assets/Crest/Crest-Examples/Examples/Scenes/Examples.unity"}:new[] {path,"Assets/CrestPortDemos/Ocean_Calm.unity","Assets/CrestPortDemos/Ocean_Interactions.unity"},
                    target=BuildTarget.StandaloneWindows64,
                    locationPathName=mode==5?"Builds/P11-ReflectionModes/ReflectionModes.exe":mode==4?"Builds/P11-CameraStack/CameraStack.exe":mode==3?"Builds/P11-RenderModes/RenderModes.exe":mode==2?"Builds/P11-OriginalScenes/OriginalScenes.exe":mode==1?"Builds/P11-OriginalExamples/OriginalExamples.exe":"Builds/P10-ResourceProbe/ResourceProbe.exe",
                    options=BuildOptions.Development,
                    extraScriptingDefines=new[] {"CREST_RESOURCE_PROBE"}
                });
                if(build.summary.result!=BuildResult.Succeeded) throw new InvalidOperationException("Diagnostic build failed.");
                Debug.Log("RESOURCE_PROBE_BUILD_SUCCEEDED bytes="+build.summary.totalSize);
            }
            finally
            {
                QualitySettings.renderPipeline=qualityPipeline;
                PlayerSettings.SetPreloadedAssets(preloadedAssets);
                PlayerSettings.enableFrameTimingStats=timing;
                PlayerSettings.strictShaderVariantMatching=strict;
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                if(Path.GetFullPath(folder).StartsWith(Path.GetFullPath(parent)+Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)
                    && AssetDatabase.AssetPathToGUID(folder)==guid) AssetDatabase.DeleteAsset(folder);
            }
        }
    }
}
