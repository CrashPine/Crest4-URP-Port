$ErrorActionPreference='Stop'
$editor='C:/Program Files/Unity/Hub/Editor/6000.6.5f1/Editor/Unity.exe'
foreach($api in @('DX11','DX12')){
 $label="P11-LocalReflection-$api"
 $start=[DateTime]::UtcNow
 $flag=if($api -eq 'DX11'){'-force-d3d11'}else{'-force-d3d12'}
 $p=Start-Process $editor -WindowStyle Hidden -Wait -PassThru -ArgumentList '-batchmode','-projectPath',('"{0}"' -f (Get-Location).Path),$flag,'-runTests','-testPlatform','EditMode','-assemblyNames','Crest.URP.Tests','-testFilter','LocalReflectionProbeTests','-testResults',('"{0}"' -f (Join-Path (Get-Location) "Evidence/$label.xml")),'-logFile',('"{0}"' -f (Join-Path (Get-Location) "Evidence/$label.log"))
 $xml=Get-Item "Evidence/$label.xml"
 [xml]$result=Get-Content $xml.FullName -Raw
 if($p.ExitCode -ne 0 -or $xml.LastWriteTimeUtc -lt $start -or $result.'test-run'.result -ne 'Passed' -or $result.'test-run'.passed -ne '1'){Write-Warning "$label failed"; continue}
 "$label passed"
}

