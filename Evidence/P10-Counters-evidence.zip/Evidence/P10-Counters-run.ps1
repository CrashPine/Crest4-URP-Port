﻿param([string]$API='DX11')
$ErrorActionPreference='Stop'
$root=(Get-Location).Path
foreach($mode in @('Empty','Ocean')){
 $name="P10-Counters-Render-$mode-$API";$start=[DateTime]::UtcNow
 [ordered]@{step=$name;status='RUNNING';startUtc=$start.ToString('o')} | ConvertTo-Json | Set-Content 'Evidence/P10-Counters-operation.json'
 $taskArgs=@('-screen-width','960','-screen-height','540','-screen-fullscreen','0','-crestResourceProbe','-crestProbeMode',$mode,'-crestCounterCapability','-crestProbeOutput',('"'+(Join-Path $root "Evidence/$name.json")+'"'),'-logFile',('"'+(Join-Path $root "Evidence/$name.log")+'"'))
 $taskArgs+=$(if($API -eq 'DX11'){'-force-d3d11'}else{'-force-d3d12'})
 if($mode -eq 'Empty'){$taskArgs+='-crestProbeDisableFeature'}
 $player=Start-Process (Join-Path $root 'Builds/P10-ResourceProbe/ResourceProbe.exe') -ArgumentList $taskArgs -WindowStyle Normal -PassThru
 if(!$player.WaitForExit(120000)){Stop-Process -Id $player.Id;throw 'Capability timed out'}
 if($player.ExitCode -ne 0){throw "Player exited $($player.ExitCode)"}
 $report=Get-Item "Evidence/$name.json";if($report.LastWriteTimeUtc -lt $start){throw 'Stale report'}
 $result=Get-Content $report.FullName -Raw | ConvertFrom-Json
 if($result.errors -ne 0 -or $result.batch -or !$result.cameraEnabled -or $result.phases.Count -ne 3 -or @($result.phases | Where-Object { $_.cameraRenders -lt 60 }).Count){throw 'Invalid capability report'}
 [ordered]@{step=$name;status='PASSED';endUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress | Add-Content 'Evidence/P10-Counters-render-completions.jsonl'
}
