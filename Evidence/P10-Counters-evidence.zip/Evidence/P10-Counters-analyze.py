from pathlib import Path
import json,hashlib,datetime
E=Path('Evidence');cases=[]
for api in ['DX11','DX12']:
 for mode in ['Empty','Ocean']:
  p=E/f'P10-Counters-Render-{mode}-{api}.json';x=json.loads(p.read_text());assert x['errors']==0 and not x['batch'] and x['cameraEnabled'] and x['development'] and x['width']==960 and x['height']==540
  assert x['api']==('Direct3D11' if api=='DX11' else 'Direct3D12') and x['featureDisabled']==(mode=='Empty')
  assert all(c['category']=='Render' for c in x['selectedCounters'])
  phases=[]
  for ph in x['phases']:
   assert ph['seconds']>=3 and len(ph['samples'])>=60 and abs(ph['cameraRenders']-len(ph['samples']))<=1
   if ph['name']=='positive64':assert ph['enabledControls']==ph['visibleControls']==64
   metrics={m['name']:m for m in ph['counters']}
   for n in ['Draw Calls Count','Triangles Count','Vertices Count','SetPass Calls Count','SRP Batcher Draw Calls Count']:assert metrics[n]['min']==metrics[n]['max'] and metrics[n]['count']==len(ph['samples'])
   fresh=[s for s in ph['samples'] if s['freshTiming']];positive=[s['gpuMs'] for s in fresh if s['gpuMs']>0]
   phases.append(dict(name=ph['name'],cameraRenders=ph['cameraRenders'],samples=len(ph['samples']),seconds=ph['seconds'],metrics=[dict(name=m['name'],unit=m['unit'],mean=m['mean'],min=m['min'],max=m['max']) for m in ph['counters']],uniqueTimings=len(fresh),positiveGpuTimings=len(positive),gpuMsMean=sum(positive)/len(positive) if positive else None))
  base,load,rest=phases
  def metric(ph,n):return next(m['mean'] for m in ph['metrics'] if m['name']==n)
  for n,d in [('Draw Calls Count',64),('Triangles Count',768),('Vertices Count',1536),('SetPass Calls Count',1),('SRP Batcher Draw Calls Count',64)]:assert metric(load,n)-metric(base,n)==d and metric(rest,n)==metric(base,n)
  log=p.with_suffix('.log').read_text(errors='replace');assert 'COUNTER_CAPABILITY_COMPLETED errors=0' in log
  status='AVAILABLE_NONZERO' if all(ph['positiveGpuTimings']>0 for ph in phases) else 'UNAVAILABLE_IN_THIS_CONTROL'
  cases.append(dict(file=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),api=api,mode=mode,selectedCounters=x['selectedCounters'],phases=phases,gpuStatus=status,frameTimingEnabled=x['frameTimingEnabled'],gpuRecorderSupported=x['gpuRecorderSupported'],gpuTimerFrequency=x['gpuTimerFrequency'],missingRenderCounterNames=['Batches Count'],warnings={k:log.count(k) for k in ['RenderData validation failed','evictable','Persistent allocates','temporary render texture','Shader error']}))
  print(api,mode,status,'draw',*[metric(ph,'Draw Calls Count') for ph in phases],'gpuMs',*[round(ph['gpuMsMean'],6) if ph['gpuMsMean'] else None for ph in phases])
normal=json.loads((E/'Build-checkpoint.json').read_text());hashes=[]
for group,key in [('builds','assembly'),('packedAssets','path')]:
 for a in normal[group]:
  p=Path('Builds')/a['configuration']/a[key];sha=hashlib.sha256(p.read_bytes()).hexdigest().upper();assert sha==a['sha256'];hashes.append(dict(path=p.as_posix(),sha256=sha))
(E/'P10-Counters-summary.json').write_text(json.dumps(dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),validation='PASSED scoped counter capability',cases=cases,normalBuildsUnchanged=hashes,limitation='GPU timing is nonzero but baseline/restored drift prevents attributable GPU cost or API/FPS ranking. Single short fixed-order3s phase after2s warm-up, Development/nonbatch/visible960x540/target60. Draw/geometry controls exactly restore; no VRAM/lifetime acceptance.'),indent=2)+'\n')
