using System;
using System.IO;
using System.Linq;
using Crest;
using Crest.URP;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public static class CleanImportProbe
{
    const string ScenePath = "Assets/Crest/Crest-Examples/Main/Scenes/main.unity";
    const string SceneGuid = "831b08ead2995f8419a358cd5da15916";
    const string OceanMaterialGuid = "ef94c26e44a36e24a9dcbc5995a2bed1";
    const string OceanShaderGuid = "668aecf91371c8b4997e42c0c7b19527";
    const string RendererPath = "Assets/Settings/PC_Renderer.asset";
    const string PipelinePath = "Assets/Settings/PC_RPAsset.asset";

    public static void Configure()
    {
        var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(RendererPath);
        var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);
        Require(renderer != null && pipeline != null, "Missing template renderer or pipeline");
        Require(GraphicsSettings.currentRenderPipeline == pipeline, "Template PC pipeline must be active");
        if (!renderer.rendererFeatures.OfType<CrestBackgroundFeature>().Any())
        {
            var feature = ScriptableObject.CreateInstance<CrestBackgroundFeature>();
            feature.name = "Crest Background";
            AssetDatabase.AddObjectToAsset(feature, renderer);
            Require(AssetDatabase.TryGetGUIDAndLocalFileIdentifier(feature, out string _, out long localId),
                "Crest feature must be a renderer subasset");
            var rendererSettings = new SerializedObject(renderer);
            var features = rendererSettings.FindProperty("m_RendererFeatures");
            var featureMap = rendererSettings.FindProperty("m_RendererFeatureMap");
            features.GetArrayElementAtIndex(features.arraySize++).objectReferenceValue = feature;
            featureMap.GetArrayElementAtIndex(featureMap.arraySize++).longValue = localId;
            rendererSettings.ApplyModifiedPropertiesWithoutUndo();
        }

        pipeline.supportsCameraDepthTexture = true;
        pipeline.supportsCameraOpaqueTexture = true;
        EditorUtility.SetDirty(renderer);
        EditorUtility.SetDirty(pipeline);
        AssetDatabase.SaveAssets();

        var scene = EditorSceneManager.OpenScene(ScenePath);
        Audit("before-save");
        EditorSceneManager.MarkSceneDirty(scene);
        Require(EditorSceneManager.SaveScene(scene), "Main scene save failed");
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        Verify();
    }

    public static void Verify()
    {
        var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(RendererPath);
        var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);
        Require(GraphicsSettings.currentRenderPipeline == pipeline, "Wrong active pipeline on reload");
        Require(pipeline.supportsCameraDepthTexture && pipeline.supportsCameraOpaqueTexture, "Camera texture settings did not persist");
        Require(renderer.rendererFeatures.OfType<CrestBackgroundFeature>().Count(feature => feature.isActive) == 1,
            "Renderer feature did not persist");
        var version = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(UniversalRenderPipeline).Assembly).version;
        Require(version == "17.6.0", "Unexpected URP " + version);
        EditorSceneManager.OpenScene(ScenePath);
        Audit("reopen");
    }

    // The original snapshot test expects exact repeated renders within one Unity frame.
    // Select the spatial SSAO sampler so the template retains AO across that comparison.
    public static void ConfigureForIdenticalCaptures()
    {
        var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(RendererPath);
        var ssao = renderer.rendererFeatures.Single(feature => feature.GetType().Name == "ScreenSpaceAmbientOcclusion");
        var settings = new SerializedObject(ssao);
        var method = settings.FindProperty("m_Settings.AOMethod");
        int gradient = Array.IndexOf(method.enumNames, "InterleavedGradient");
        Require(gradient >= 0, "Interleaved gradient unavailable");
        method.enumValueIndex = gradient;
        settings.ApplyModifiedPropertiesWithoutUndo();
        var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);
        pipeline.gpuResidentDrawerMode = GPUResidentDrawerMode.Disabled;
        EditorUtility.SetDirty(pipeline);
        AssetDatabase.SaveAssets();
        File.AppendAllText("Evidence/import.txt", "Identical capture control: SSAO Interleaved Gradient; GPU Resident Drawer disabled for synchronous renderer visibility toggles.\n");
    }

    static void Audit(string phase)
    {
        var scene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
        var roots = scene.GetRootGameObjects();
        var objects = roots.SelectMany(root => root.GetComponentsInChildren<Transform>(true)).ToArray();
        int missing = objects.Sum(transform => GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(transform.gameObject));
        var ocean = objects.Select(item => item.GetComponent<OceanRenderer>()).Single(item => item != null);
        var camera = Camera.main;
        var oceanMaterial = ocean.OceanMaterial;
        string materialPath = AssetDatabase.GetAssetPath(oceanMaterial);
        string materialGuid = AssetDatabase.AssetPathToGUID(materialPath);
        string shaderPath = AssetDatabase.GetAssetPath(oceanMaterial.shader);
        string shaderGuid = AssetDatabase.AssetPathToGUID(shaderPath);
        string report = $"{phase}; Unity={Application.unityVersion}; Scene={scene.path}; GUID={AssetDatabase.AssetPathToGUID(scene.path)}; "
            + $"Roots={roots.Length}; Objects={objects.Length}; MissingScripts={missing}; OceanMaterial={materialPath}; "
            + $"MaterialGUID={materialGuid}; Shader={shaderPath}; ShaderGUID={shaderGuid}; Camera={camera?.name}\n";
        File.AppendAllText("Evidence/import.txt", report);
        Debug.Log(report);
        Require(AssetDatabase.AssetPathToGUID(scene.path) == SceneGuid, "Original scene GUID changed");
        Require(missing == 0 && camera != null, "Main camera or components missing after import");
        Require(materialGuid == OceanMaterialGuid && shaderGuid == OceanShaderGuid && oceanMaterial.shader.isSupported,
            "Original ocean material or shader binding unresolved");
    }

    static void Require(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
