param([string]$API='DX11')
$ErrorActionPreference='Stop'
./Tools/Run-Unity.ps1 -Editor 'C:/Program Files/Unity/Hub/Editor/6000.6.5f1/Editor/Unity.exe' -Action EditMode -GraphicsAPI $API -TestFilter WhirlpoolDampingTests
Copy-Item "Evidence/EditMode-$API-focused.xml" "Evidence/P11-Whirlpool-$API.xml"
