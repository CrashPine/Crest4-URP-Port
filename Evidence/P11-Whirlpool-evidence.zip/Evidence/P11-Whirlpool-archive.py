from pathlib import Path
import zipfile,json,hashlib
E=Path('Evidence');raw=[p for p in E.glob('P11-Whirlpool-*') if p.suffix!='.zip' and p.name not in ['P11-Whirlpool-summary.json','P11-Whirlpool-files.json']]
sources=[Path(n) for n in ['Assets/Crest/URP/Tests/Editor/OriginalWhirlpoolTests.cs','Assets/Crest/URP/Tests/Editor/OriginalWhirlpoolTests.cs.meta','Assets/Crest/URP/Tests/Editor/RippleGeneratorTests.cs','Assets/Crest/Crest/Scripts/LodData/LodDataMgrPersistent.cs','Assets/Crest/Crest/Scripts/LodData/LodDataMgrDynWaves.cs','Assets/Crest/Crest/Scripts/LodData/RegisterLodDataInput.cs','Assets/Crest/Crest/Scripts/Interaction/SphereWaterInteraction.cs','Assets/Crest/Crest-Examples/Whirlpool/Scripts/Whirlpool.cs','Assets/Crest/Crest/Shaders/OceanInputs/Resources/DynWavesDampenCircle.shader','Assets/Crest/Crest/Shaders/Resources/UpdateDynWaves.compute']]
assemblies=list(Path('Library/ScriptAssemblies').glob('Crest*.dll'));assert len(assemblies)==7
logs=[E/f'EditMode-{api}-focused.log' for api in ['DX11','DX12']]
files=sorted(set(raw+sources+assemblies+logs));archive=E/'P11-Whirlpool-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
manifest=[dict(path=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest().upper(),bytes=p.stat().st_size) for p in files]
with zipfile.ZipFile(archive) as z:
 for f in manifest:assert hashlib.sha256(z.read(f['path'])).hexdigest().upper()==f['sha256']
(E/'P11-Whirlpool-files.json').write_text(json.dumps(dict(archive=archive.as_posix(),sha256=hashlib.sha256(archive.read_bytes()).hexdigest().upper(),entries=manifest),indent=2)+'\n')
with zipfile.ZipFile(E/'P11-Whirlpool-before.zip') as z:
 for n in ['Evidence/EditMode-DX11-focused.xml','Evidence/EditMode-DX12-focused.xml']:Path(n).write_bytes(z.read(n))
for p in raw:p.unlink()
print('Archived',len(files),'files /7 actual Editor assemblies; verified hashes; restored original focused XML')
