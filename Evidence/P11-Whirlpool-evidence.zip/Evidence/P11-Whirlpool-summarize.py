from pathlib import Path
import json,hashlib,re,xml.etree.ElementTree as ET,subprocess
E=Path('Evidence');results=[]
for api in ['DX11','DX12']:
 r=ET.parse(E/f'P11-Whirlpool-{api}.xml').getroot();assert r.attrib['result']=='Passed' and len(list(r.iter('test-case')))==1
 text=(E/f'P11-Whirlpool-Direct3D{api[2:]}.txt').read_text();values={k:float(re.search(r'\b'+k+r'=([-+]?\d+(?:[,.]\d+)?(?:[Ee][-+]?\d+)?)',text).group(1).replace(',','.')) for k in ['MatchedSphereSources','Radius','NativeStrength','Frequency','Interior','Outside','NativeRGError','StrongRGError','NativeInteriorDelta','OutsideDelta','MatchedOffRepeatError']}
 log=(E/f'EditMode-{api}-focused.log').read_text(errors='replace');warnings={k:len(re.findall(pattern,log,re.I)) for k,pattern in {'shaderErrors':'Shader error in','renderData':'RenderData validation failed','persistent':'Persistent allocates','evictable':'evictable'}.items()};assert not any(warnings.values())
 assert values['NativeRGError']<.0006 and values['StrongRGError']<.0006 and values['OutsideDelta']==0 and values['MatchedOffRepeatError']==0
 results.append(dict(api=api,passed=1,values=values,warnings=warnings))
x=json.loads((E/'Build-checkpoint.json').read_text(encoding='utf-8-sig'))
for a in x['runtimeSources']+x['materialSources']:assert hashlib.sha256(Path(a['path']).read_bytes()).hexdigest().upper()==a['sha256']
for group,key in [('builds','assembly'),('packedAssets','path')]:
 for a in x[group]:assert hashlib.sha256((Path('Builds')/a['configuration']/a[key]).read_bytes()).hexdigest().upper()==a['sha256']
old=subprocess.check_output(['git','show','HEAD:Assets/Crest/URP/Tests/Editor/OriginalWhirlpoolTests.cs']).decode('utf-8-sig').replace('\r\n','\n');assert Path('Assets/Crest/URP/Tests/Editor/OriginalWhirlpoolTests.cs').read_text(encoding='utf-8-sig').startswith(old)
for i in range(4):assert (E/f'P11-Whirlpool-Direct3D11-trial{i}-lod0.bin').read_bytes()==(E/f'P11-Whirlpool-Direct3D12-trial{i}-lod0.bin').read_bytes()
(E/'P11-Whirlpool-summary.json').write_text(json.dumps({'validation':'P11.1 scoped matched-history damping control Passed1/API','results':results,'crossApiLod0PairsByteIdentical':4,'productionSourcesAndMaterialsUnchanged':True,'normalArtifactsUnchanged':12,'normalCheckpoint':'e4cbf02 full117+interactive2/API; no new full118 suite claimed','correction':'Test-only matched sphere forcing snapshot at order199 before Ocean200, no tolerance change;2 sphere components/registration remain active','limits':'Seeded dynamic RG history and matched forcing with one positive native substep; no long-term combined temporal/API visual/standalone/performance claim; old .015754165 failure retained, not explained by this control.'},indent=2)+'\n')
print(json.dumps(results,indent=2))
