"""Stage both verified Crest Windows builds and check the extracted payload."""
from hashlib import file_digest
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
from xml.etree import ElementTree

base = Path(__file__).resolve().parent
project = base / "F"
evidence = project / "Evidence"
stage = base / "P13-Final-packages"


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def verify_tests():
    for api in ("d3d11", "d3d12"):
        for suite, expected in (("batch", 147), ("interactive", 3)):
            report = evidence / f"P13-Final-{api}-{suite}.xml"
            result = ElementTree.parse(report).getroot().attrib
            if (
                result["result"] != "Passed"
                or int(result["total"]) != expected
                or int(result["passed"]) != expected
                or result["skipped"] != "0"
            ):
                raise RuntimeError(f"Incomplete test run: {report}")


def package(config, revision):
    source = project / "Builds" / config
    files = {
        path.relative_to(source).as_posix(): path
        for path in sorted(source.rglob("*"))
        if path.is_file()
        and not any(part.endswith("_ButDontShipItWithYourGame") for part in path.relative_to(source).parts)
    }
    for expected in ("CrestPort.exe", "UnityPlayer.dll", "CrestPort_Data/Managed/Crest.dll"):
        if expected not in files:
            raise RuntimeError(f"{config} missing {expected}")
    for notice in ("LICENSE.Crest", "THIRD_PARTY_NOTICES.md"):
        files[notice] = base.parent / notice
    manifest = {name: digest(path) for name, path in sorted(files.items())}
    filename = f"Crest4-URP-Windows-{config}-{revision[:7]}.zip"
    archive = stage / filename
    with ZipFile(archive, "x", ZIP_DEFLATED, compresslevel=3) as output:
        for name, path in files.items():
            output.write(path, name)
        output.writestr("SHA256.json", json.dumps(manifest, indent=2) + "\n")
    unpacked = stage / config
    unpacked.mkdir()
    with ZipFile(archive) as output:
        if set(output.namelist()) != manifest.keys() | {"SHA256.json"}:
            raise RuntimeError(f"Unexpected archive entries: {archive}")
        output.extractall(unpacked)
    checked = json.loads((unpacked / "SHA256.json").read_text())
    if checked != manifest:
        raise RuntimeError(f"Manifest mismatch: {archive}")
    for name, expected in checked.items():
        if digest(unpacked / name) != expected:
            raise RuntimeError(f"Extracted hash mismatch: {config} {name}")
    return dict(configuration=config, path=f"Builds/{filename}", files=len(files),
                bytes=archive.stat().st_size, sha256=digest(archive))


def main():
    verify_tests()
    revision = (evidence / "candidate.txt").read_text(encoding="utf-8-sig").strip()
    stage.mkdir()
    reports = [package(config, revision) for config in ("Development", "Release")]
    (evidence / "packages.json").write_text(json.dumps(reports, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(reports, indent=2))


if __name__ == "__main__":
    main()
