$ErrorActionPreference='Stop'
$project='R:\F'
$unity='C:/Program Files/Unity/Hub/Editor/6000.6.5f1/Editor/Unity.exe'
$evidence=Join-Path $project Evidence
function RunEditor([string]$name,[string[]]$options){
 $started=[DateTime]::UtcNow
 $log=Join-Path $evidence "$name.log"
 $arguments=@('-projectPath',('"{0}"' -f $project),'-logFile',('"{0}"' -f $log))+$options
 "$name started $($started.ToString('o'))"
 $p=Start-Process -FilePath $unity -ArgumentList $arguments -WorkingDirectory $project -WindowStyle Hidden -PassThru
 if(!$p.WaitForExit(720000)){Stop-Process -Id $p.Id;throw "$name Editor timed out"}
 if($p.ExitCode){throw "$name failed exit $($p.ExitCode)"}
 if(!(Test-Path -LiteralPath $log) -or (Get-Item -LiteralPath $log).LastWriteTimeUtc -lt $started){throw "$name missing fresh log"}
 "$name passed $([DateTime]::UtcNow.ToString('o'))"
}
foreach($api in 'd3d11','d3d12'){
 foreach($suite in 'batch','interactive'){
  $name="P13-Final-$api-$suite"
  $assembly=if($suite -eq 'batch'){'Crest.URP.Tests'}else{'Crest.URP.Interactive.Tests'}
  $args=@("-force-$api",'-runTests','-testPlatform','EditMode','-assemblyNames',$assembly,'-testResults',"Evidence/$name.xml")
  if($suite -eq 'batch'){$args=@('-batchmode')+$args}
  RunEditor $name $args
  [xml]$xml=Get-Content -LiteralPath (Join-Path $evidence "$name.xml") -Raw
  $run=$xml.'test-run'
  $expected=if($suite -eq 'batch'){147}else{3}
  if($run.result -ne 'Passed' -or [int]$run.total -ne $expected -or [int]$run.passed -ne $expected -or [int]$run.skipped){throw "$name incomplete: $($run.result) $($run.passed)/$($run.total)"}
  "$name $($run.passed)/$($run.total)"
 }
}
# The tests may trigger Unity material normalization. Build the archived candidate bytes.
tar -xf 'R:\P13-Final-source.tar' -C $project
if($LASTEXITCODE){throw 'Could not restore the candidate source before building'}
RunEditor 'P13-Final-ValidateAssets' @('-batchmode','-quit','-force-d3d11','-executeMethod','Crest.URP.Editor.PortAutomation.ValidateAssets')
if(!(Select-String -LiteralPath (Join-Path $evidence 'P13-Final-ValidateAssets.log') -SimpleMatch 'CREST_ASSET_VALIDATION: no reported asset errors.')){throw 'Asset validation success marker not found'}
foreach($config in 'Development','Release'){
 RunEditor "P13-Final-$config-build" @('-batchmode','-quit','-force-d3d11','-executeMethod',"Crest.URP.Editor.PortAutomation.Build$config")
 if(!(Test-Path -LiteralPath (Join-Path $project "Builds/$config/CrestPort.exe"))){throw "$config missing executable"}
}
'FINAL_BUILD_READY'
