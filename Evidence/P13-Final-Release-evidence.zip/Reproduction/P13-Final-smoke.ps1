$ErrorActionPreference='Stop'
$base=$PSScriptRoot
$project=Join-Path $base F
$stage=Join-Path $base 'P13-Final-packages'
$packageReport=Join-Path $project 'Evidence/packages.json'
if(!(Test-Path -LiteralPath $packageReport)){
 & py -3.13 (Join-Path $base 'P13-Final-package.py')
 if($LASTEXITCODE){throw 'Windows packaging or unpacked digest check failed'}
}
foreach($config in 'Development','Release'){
 foreach($api in 'DX11','DX12'){
  $name="Player-$config-$api"
  "$name started $([DateTime]::UtcNow.ToString('o'))"
  & (Join-Path $project 'Tools/Run-Player.ps1') -Player (Join-Path $stage "$config/CrestPort.exe") -GraphicsAPI $api -Label $config -ReflectionOptions
  "$name passed $([DateTime]::UtcNow.ToString('o'))"
 }
}
'FINAL_SMOKES_READY'
