"""Create the P13 validation archive and candidate build checkpoint."""
from datetime import datetime, timezone
from hashlib import file_digest
import json
from pathlib import Path
import re
from tarfile import open as open_tar
from xml.etree import ElementTree
from zipfile import ZipFile, ZIP_DEFLATED

base = Path(__file__).resolve().parent
root = base.parent
project = base / "F"
evidence = project / "Evidence"
payload = base / "P13-Final-packages"
archive_path = root / "Evidence/P13-Final-Release-evidence.zip"

WARNING_MARKERS = (
    "Persistent allocates", "JobTempAlloc", "evictable",
    "RenderData validation failed",
    "Releasing render texture that is set to be RenderTexture.active!",
    "D3D12PipelineLibrary must be recreated",
)


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def describe(path):
    return dict(
        path=path.relative_to(evidence).as_posix(),
        sha256=digest(path),
        bytes=path.stat().st_size,
        modifiedUtc=datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(),
    )


def main():
    revision = (evidence / "candidate.txt").read_text(encoding="utf-8-sig").strip()
    packages = json.loads((evidence / "packages.json").read_text())
    tests = []
    for api in ("DX11", "DX12"):
        for profile, count in (("batch", 147), ("interactive", 3)):
            ref = evidence / f"P13-Final-d3d{api[2:]}-{profile}.xml"
            report = ElementTree.parse(ref).getroot().attrib
            if {report["result"], report["total"], report["passed"], report["skipped"]} != {"Passed", str(count), "0"}:
                raise RuntimeError(f"Incomplete tests: {ref}")
            tests.append(dict(api=api, profile=profile, total=count, startUtc=report["start-time"],
                              endUtc=report["end-time"], **describe(ref)))

    smokes = []
    builds = []
    packed = []
    for package in packages:
        config = package["configuration"]
        zip_file = payload / Path(package["path"]).name
        if digest(zip_file) != package["sha256"]:
            raise RuntimeError(f"Package checksum changed: {zip_file}")
        unpacked = payload / config
        manifest = json.loads((unpacked / "SHA256.json").read_text())
        for name, expected in manifest.items():
            if digest(unpacked / name) != expected:
                raise RuntimeError(f"Unpacked checksum changed: {config} {name}")
        for name in ("Crest.dll", "Crest.URP.dll", "Crest.Examples.dll"):
            relative = f"CrestPort_Data/Managed/{name}"
            builds.append(dict(configuration=config, assembly=relative, sha256=manifest[relative],
                               bytes=(unpacked / relative).stat().st_size))
        for name in ("resources.assets", "sharedassets0.assets", "globalgamemanagers"):
            relative = f"CrestPort_Data/{name}"
            packed.append(dict(configuration=config, path=relative, sha256=manifest[relative],
                               bytes=(unpacked / relative).stat().st_size))
        for api in ("DX11", "DX12"):
            folder = evidence / f"Player-{config}-{api}"
            report = folder / "player-smoke.txt"
            player_log = folder / "Player.log"
            log_text = player_log.read_text(encoding="utf-8-sig", errors="replace")
            smoke_text = report.read_text(encoding="utf-8-sig", errors="replace")
            if f"Unity=6000.6.5f1; API=Direct3D{api[2:]};" not in smoke_text:
                raise RuntimeError(f"Expected Unity version and graphics API are missing: {report}")
            frames = re.findall(r"^CaptureFrame: scene=([^;]+); frame=(\d+); lodFrame=(\d+)", smoke_text, flags=re.M)
            images = sorted(folder.glob("*.png"))
            if len(frames) != 7 or any(frame != lod_frame for _, frame, lod_frame in frames):
                raise RuntimeError(f"Current-frame capture evidence missing: {report}")
            if len(images) != 11 or not re.search(r"^Errors=0\.", smoke_text, flags=re.M):
                raise RuntimeError(f"Incomplete smoke: {report}")
            smokes.append(dict(configuration=config, graphicsAPI=api, errors=0, report=describe(report),
                               playerLog=describe(player_log), images=[describe(path) for path in images],
                               reflectionReport=describe(folder / "reflection-options.txt"),
                               warnings={marker: log_text.count(marker) for marker in WARNING_MARKERS}))

    warnings = {}
    for path in sorted(evidence.glob("P13-Final-*.log")):
        log = path.read_text(encoding="utf-8-sig", errors="replace")
        warnings[path.name] = {marker: log.count(marker) for marker in WARNING_MARKERS}

    previous = json.loads((root / "Evidence/Build-checkpoint.json").read_text(encoding="utf-8-sig"))
    source_paths = {row["path"] for row in previous["runtimeSources"] + previous["materialSources"]}
    source_paths.update((
        "Assets/Crest/Crest/Scripts/OceanRenderer.cs",
        "Assets/Crest/Crest/Scripts/Helpers/RenderAlphaOnSurface.cs",
        "Assets/Crest/Crest/Scripts/Helpers/RenderWireFrame.cs",
        "Assets/Crest/Crest/Scripts/Shapes/ShapeGerstnerSplineHandling.cs",
        "Assets/CrestPortDemos/Ocean_LargeWaves.unity",
        "Packages/manifest.json",
        "ProjectSettings/ProjectSettings.asset",
    ))
    runtime = []
    with open_tar(base / "P13-Final-source.tar") as source:
        for name in sorted(source_paths):
            member = source.getmember(name)
            with source.extractfile(member) as stream:
                runtime.append(dict(path=name, sha256=file_digest(stream, "sha256").hexdigest(), bytes=member.size))

    with ZipFile(archive_path, "x", ZIP_DEFLATED, compresslevel=4) as output:
        evidence_files = list(evidence.glob("P13-Final-*")) + [
            evidence / name for name in ("candidate.txt", "upstream.txt", "guid-and-compute.json", "packages.json")
        ]
        evidence_files.extend((evidence / "RiverBackground-baseline").glob("*"))
        evidence_files.extend(evidence.glob("OriginalLakesRivers-Direct3D*.txt"))
        for group in (path for path in evidence.glob("Player-*") if path.is_dir()):
            evidence_files.extend(group.glob("*"))
        for item in sorted(evidence_files):
            if item.is_file():
                output.write(item, item.relative_to(evidence).as_posix())
        for name in ("P13-Final-run.ps1", "P13-Final-package.py", "P13-Final-smoke.ps1", Path(__file__).name):
            output.write(base / name, "Reproduction/" + name)
    with ZipFile(archive_path) as checked:
        if checked.testzip():
            raise RuntimeError("Check archive failed")

    checkpoint = dict(recordedUtc=datetime.now(timezone.utc).isoformat(), unity="6000.6.5f1", urp="17.6.0",
                      candidateCommit=revision, strictShaderVariantMatching=True,
                      validationStatus="P13.7 full 147 plus Game View 3 per API, ValidateAssets, both builds and four unpacked Player smokes passed.",
                      evidenceArchive=dict(path=archive_path.relative_to(root).as_posix(), sha256=digest(archive_path),
                                           bytes=archive_path.stat().st_size),
                      testReports=tests, assetValidation=describe(evidence / "P13-Final-ValidateAssets.log"),
                      provenance=describe(evidence / "guid-and-compute.json"),
                      runtimeSources=runtime, builds=builds, packedAssets=packed, smokes=smokes,
                      packages=packages, editorLogWarnings=warnings,
                      previousCheckpoint="P12 validated checkpoint in git history; see P12-Windows-packages-066a5c0.json",
                      limitation="Windows native DX11/DX12 Render Graph and listed cases. VR excluded. Driver residency limits in TEST_RESULTS.md.")
    path = base / "P13-Final-Build-checkpoint.json"
    path.write_text(json.dumps(checkpoint, indent=2) + "\n", encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()
