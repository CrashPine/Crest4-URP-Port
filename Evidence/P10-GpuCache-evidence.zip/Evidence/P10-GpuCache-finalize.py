﻿from pathlib import Path
import json,hashlib,datetime,subprocess,zipfile,xml.etree.ElementTree as ET
E=Path('Evidence'); prefix='P10-GpuCache-'
def fp(p):
 p=Path(p);return dict(path=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest().upper(),bytes=p.stat().st_size,modifiedUtc=datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc).isoformat())
def write(p,x):Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
ops=json.loads((E/(prefix+'operations.json')).read_text(encoding='utf-8-sig'))
assert all(any(o['step']==s and o['status']=='PASSED' for o in ops) for s in ['EditMode-DX11','EditMode-DX11-interactive','EditMode-DX12','EditMode-DX12-interactive','Development-DX11','Release-DX11'])
suites=[]
for api in ['DX11','DX12']:
 for suffix,n in [('',110),('-interactive',2)]:
  p=E/f'{prefix}EditMode-{api}{suffix}.xml';r=ET.parse(p).getroot();leaves=list(r.iter('test-case'))
  assert r.attrib['result']=='Passed' and len(leaves)==n and all(t.attrib['result']=='Passed' for t in leaves)
  suites.append(dict(**fp(p),passed=n,start=r.attrib['start-time'],end=r.attrib['end-time']))
for config in ['Development','Release']:
 assert 'Build Finished, Result: Success.' in (E/f'{config}-DX11.log').read_text(errors='replace')
 for api in ['DX11','DX12']:
  d=E/f'Player-{config}-{api}';assert 'Errors=0.' in (d/'player-smoke.txt').read_text();assert len(list(d.glob('*.png')))==11
x=json.loads((E/'Build-checkpoint.json').read_text(encoding='utf-8-sig'))
x['recordedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
for group in ['runtimeSources','materialSources','buildLogs']:
 for a in x[group]:a.update(fp(a['path']))
for path in ['Assets/Crest/Crest/Scripts/Underwater/UnderwaterRenderer.Mask.cs','Assets/Crest/Crest/Scripts/Underwater/UnderwaterRenderer.cs']:
 if path not in [a['path'] for a in x['runtimeSources']]:x['runtimeSources'].append(fp(path))
for group,key in [('builds','assembly'),('packedAssets','path')]:
 for a in x[group]:
  f=fp(Path('Builds')/a['configuration']/a[key]);a.update({k:v for k,v in f.items() if k!='path'})
for a in x['smokes']:
 a['report']=fp(a['report']['path']);a['images']=[fp(i['path']) for i in a['images']]
 log=Path(a['report']['path']).parent/'Player.log';a['warnings']=[line for line in log.read_text(errors='replace').splitlines() if 'RenderData validation failed' in line];a['playerLog']=fp(log)
x['limitation']='Scoped per-enabled-lifetime GPU classification cache; native warm Off/On GC windows only. Common448B Submit remains; real Intel/XR unavailable. Historical driver retention/evictable and broader P10/P11 coverage open. Existing Shadow RenderData frame-validation warnings recur and also occur in archived pre-fix runs; unresolved, not clean-log acceptance.'
x['validationStatus']='Full110+actual interactive2/API Passed; Development/Release Success;4 sequential Player smokes Errors0,7 scenes+4 reflection captures each.'
x['previousGPUCacheArchive']={'path':'Evidence/P10-GpuCache-before.zip','entry':'Evidence/Build-checkpoint.json'}
write(E/'Build-checkpoint.json',x)
write(E/(prefix+'checkpoint.json'),dict(recordedUtc=x['recordedUtc'],suites=suites,gc=json.loads((E/(prefix+'gc-summary.json')).read_text()),buildCheckpoint=fp(E/'Build-checkpoint.json'),limitation=x['limitation']))
print('Validated suites/builds/smokes; updated22 runtime fingerprints and build checkpoint')
