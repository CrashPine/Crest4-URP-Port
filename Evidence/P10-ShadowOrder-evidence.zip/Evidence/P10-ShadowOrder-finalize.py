﻿from pathlib import Path
import json,hashlib,datetime,subprocess,zipfile,xml.etree.ElementTree as ET
E=Path('Evidence'); prefix='P10-ShadowOrder-'
def fp(p):
 p=Path(p);return dict(path=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest().upper(),bytes=p.stat().st_size,modifiedUtc=datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc).isoformat())
def write(p,x):Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
ops=json.loads((E/(prefix+'operations.json')).read_text(encoding='utf-8-sig'))
assert all(any(o['step']==s and o['status']=='PASSED' for o in ops) for s in ['EditMode-DX11','EditMode-DX11-interactive','EditMode-DX12','EditMode-DX12-interactive','Development-DX11','Release-DX11'])
suites=[]
for api in ['DX11','DX12']:
 for suffix,n in [('',110),('-interactive',2)]:
  p=E/f'{prefix}EditMode-{api}{suffix}.xml';r=ET.parse(p).getroot();leaves=list(r.iter('test-case'))
  assert r.attrib['result']=='Passed' and len(leaves)==n and all(t.attrib['result']=='Passed' for t in leaves)
  suites.append(dict(**fp(p),passed=n,start=r.attrib['start-time'],end=r.attrib['end-time']))
for config in ['Development','Release']:
 assert 'Build Finished, Result: Success.' in (E/f'{config}-DX11.log').read_text(errors='replace')
 for api in ['DX11','DX12']:
  d=E/f'Player-{config}-{api}';assert 'Errors=0.' in (d/'player-smoke.txt').read_text();assert len(list(d.glob('*.png')))==11
x=json.loads((E/'Build-checkpoint.json').read_text(encoding='utf-8-sig'))
x['recordedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
for group in ['runtimeSources','materialSources','buildLogs']:
 for a in x[group]:a.update(fp(a['path']))
for path in ['Assets/Crest/Crest/Scripts/Underwater/UnderwaterRenderer.Mask.cs','Assets/Crest/Crest/Scripts/Underwater/UnderwaterRenderer.cs']:
 if path not in [a['path'] for a in x['runtimeSources']]:x['runtimeSources'].append(fp(path))
for group,key in [('builds','assembly'),('packedAssets','path')]:
 for a in x[group]:
  f=fp(Path('Builds')/a['configuration']/a[key]);a.update({k:v for k,v in f.items() if k!='path'})
for a in x['smokes']:
 a['report']=fp(a['report']['path']);a['images']=[fp(i['path']) for i in a['images']]
 log=Path(a['report']['path']).parent/'Player.log';a['warnings']=[line for line in log.read_text(errors='replace').splitlines() if 'RenderData validation failed' in line];a['playerLog']=fp(log)
x['limitation']='Demo smoke capture scheduled after Ocean LateUpdate; trace proves prior coroutine used previous-frame LOD. Shadow algorithm/validation unchanged. Remaining P10 resources/GPU/NonLocal and P11 configurations open; real XR/Intel unavailable.'
x['validationStatus']='Full110+actual interactive2/API Passed; Development/Release Success;4 sequential Player smokes Errors0,7 scenes+4 reflection captures each.'
x['previousGPUCacheArchive']={'path':'Evidence/P10-ShadowOrder-before.zip','entry':'Evidence/Build-checkpoint.json'}
write(E/'Build-checkpoint.json',x)
write(E/(prefix+'checkpoint.json'),dict(recordedUtc=x['recordedUtc'],suites=suites,cause=json.loads((E/(prefix+'cause-summary.json')).read_text()),buildCheckpoint=fp(E/'Build-checkpoint.json'),limitation=x['limitation']))
print('Validated suites/builds/smokes; updated22 runtime fingerprints and build checkpoint')

import re
pairs=[]
for config in ['Development','Release']:
 for api in ['DX11','DX12']:
  d=E/f'Player-{config}-{api}'
  text=(d/'player-smoke.txt').read_text()
  rows=re.findall(r'CaptureFrame: scene=([^;]+); frame=(\d+); lodFrame=(\d+)',text)
  assert len(rows)==7 and all(frame==lod for _,frame,lod in rows)
  assert 'RenderData validation failed' not in (d/'Player.log').read_text(errors='replace')
  pairs.append(dict(configuration=config,api=api,captures=[dict(scene=s,frame=int(f),lodFrame=int(l)) for s,f,l in rows],renderDataWarnings=0))
core=[]
for path in ['Assets/Crest/Crest/Scripts/OceanRenderer.cs','Assets/Crest/Crest/Scripts/LodData/Shadows/LodDataMgrShadow.URP.cs']:
 assert Path(path).read_bytes()==subprocess.check_output(['git','show','HEAD:'+path])
 core.append(fp(path))
cp=E/(prefix+'checkpoint.json');r=json.loads(cp.read_text());r.update(captureControls=pairs,unchangedCoreSources=core,smokeSources=[fp('Assets/Crest/URP/Runtime/PortDemoController.cs'),fp('Tools/Run-Player.ps1')]);write(cp,r)
print('Validated all28 current-frame captures/no RenderData warnings; core sources unchanged')

causePath=E/(prefix+'cause-summary.json');cause=json.loads(causePath.read_text());cause['scope']='DX11 diagnostic causal pair; subsequent full/default DX11/DX12 regression and4 Players accepted with28 current-frame captures and0 RenderData warnings';write(causePath,cause)
r['cause']=cause;write(cp,r)
