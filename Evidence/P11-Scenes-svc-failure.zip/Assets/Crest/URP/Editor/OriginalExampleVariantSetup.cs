// Retain the observed unlightmapped mixed-light example variant. MIT.
using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace Crest.URP.Editor
{
    public static class OriginalExampleVariantSetup
    {
        const string Path = "Assets/CrestPortDemos/OriginalMixedLightingVariants.shadervariants";
        public static void Configure()
        {
            var collection = AssetDatabase.LoadAssetAtPath<ShaderVariantCollection>(Path);
            if (collection == null)
            {
                if (!string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(Path))) throw new InvalidOperationException("Do not overwrite an unrelated variant asset.");
                collection = new ShaderVariantCollection { name = "OriginalMixedLightingVariants" };
                AssetDatabase.CreateAsset(collection, Path);
            }
            var shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) throw new InvalidOperationException("URP Lit is required.");
            var variant = new ShaderVariantCollection.ShaderVariant(shader, PassType.ScriptableRenderPipeline,
                "FOG_EXP", "LIGHTMAP_SHADOW_MIXING", "_ADDITIONAL_LIGHTS", "_MAIN_LIGHT_SHADOWS", "REFLECTION_PROBE_ROTATION");
            if (!collection.Contains(variant)) collection.Add(variant);
            EditorUtility.SetDirty(collection);
            var graphics = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset").FirstOrDefault();
            if (graphics == null) throw new InvalidOperationException("GraphicsSettings asset unavailable.");
            var settings = new SerializedObject(graphics);var preloaded = settings.FindProperty("m_PreloadedShaders");
            if (preloaded == null || !preloaded.isArray) throw new InvalidOperationException("Preloaded shader collection field unavailable.");
            bool present = Enumerable.Range(0, preloaded.arraySize).Any(i => preloaded.GetArrayElementAtIndex(i).objectReferenceValue == collection);
            if (!present)
            {
                int index = preloaded.arraySize;preloaded.arraySize++;
                preloaded.GetArrayElementAtIndex(index).objectReferenceValue = collection;
                settings.ApplyModifiedPropertiesWithoutUndo();EditorUtility.SetDirty(graphics);
            }
            AssetDatabase.SaveAssets();
            Debug.Log("CREST_ORIGINAL_MIXED_VARIANTS: " + collection.variantCount + " explicit variants; automatic lightmap stripping remains enabled.");
        }
    }
}
