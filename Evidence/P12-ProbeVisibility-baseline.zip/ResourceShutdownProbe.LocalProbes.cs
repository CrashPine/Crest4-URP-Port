// Compiled transfer of the two optional local-probe controls. MIT.
#if CREST_RESOURCE_PROBE
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.RenderGraphModule;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace Crest.URP.Diagnostics
{
    public sealed partial class ResourceShutdownProbe
    {
        [Serializable]
        sealed class LocalProbeReport
        {
            public string api, unity, failure, forwardMode, clusterMode;
            public int boxPixels, atlasPixels, boxRestore, atlasRestore, boxProbeResponse, errors;
            public bool passed;
            public List<LocalProbeCapture> captures = new List<LocalProbeCapture>();
        }

        [Serializable]
        sealed class LocalProbeCapture
        {
            public string state;
            public int observerCalls, width, height, nonClearPixels;
            public List<string> probes = new List<string>();
        }

        sealed class LocalProbeObserver : ICameraGraphPass
        {
            public RenderPassEvent Stage => RenderPassEvent.AfterRendering;
            public Camera Camera;
            public LocalProbeCapture Capture;

            public void Record(RenderGraph graph, ContextContainer context)
            {
                var camera = context.Get<UniversalCameraData>();
                if (Capture == null || camera.camera != Camera) return;
                Capture.observerCalls++;
                Capture.width = camera.cameraTargetDescriptor.width;
                Capture.height = camera.cameraTargetDescriptor.height;
                foreach (var probe in context.Get<UniversalRenderingData>().cullResults.visibleReflectionProbes)
                {
                    var texture = probe.texture;
                    var component = probe.reflectionProbe;
                    Capture.probes.Add($"{component?.name}: texture={texture?.name}, box={probe.isBoxProjection}");
                }
            }
        }

        LocalProbeReport _localProbes;

        void SaveLocalProbes(string failure = "")
        {
            _localProbes.failure = failure;
            _localProbes.errors = _errors;
            File.WriteAllText(Argument("-crestProbeOutput", "LocalProbes.json"), JsonUtility.ToJson(_localProbes, true));
        }

        IEnumerator LocalProbesPlayer()
        {
            _localProbes = new LocalProbeReport { api = SystemInfo.graphicsDeviceType.ToString(), unity = Application.unityVersion };
            var arguments = Environment.GetCommandLineArgs();
            bool runBox = Array.IndexOf(arguments, "-crestProbeAtlasOnly") < 0;
            bool runAtlas = Array.IndexOf(arguments, "-crestProbeBoxOnly") < 0;
            yield return SceneManager.LoadSceneAsync(1);
            var camera = Camera.main;
            var settings = camera.GetUniversalAdditionalCameraData();
            var qualityPipeline = QualitySettings.renderPipeline;
            var atlasPipeline = Resources.Load<UniversalRenderPipelineAsset>("CrestLocalProbeAtlasPipeline");
            var boxPipeline = Resources.Load<UniversalRenderPipelineAsset>("CrestLocalProbeBoxPipeline");
            CheckExample(atlasPipeline != null && atlasPipeline.reflectionProbeBlending && atlasPipeline.reflectionProbeAtlas && !atlasPipeline.reflectionProbeBoxProjection
                && boxPipeline != null && boxPipeline.reflectionProbeBoxProjection && !boxPipeline.reflectionProbeBlending,
                "Missing distinct serialized probe pipeline settings");
            camera.enabled = false;
            camera.transform.SetPositionAndRotation(new Vector3(0, 4, -12), Quaternion.Euler(16, 0, 0));
            camera.cullingMask = 1 << 4;
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = Color.blue;
            camera.allowHDR = camera.allowMSAA = false;
            settings.renderPostProcessing = false;
            foreach (var shape in FindObjectsByType<ShapeWaves>()) shape.enabled = false;
            var ocean = OceanRenderer.Instance;
            var original = ocean.OceanMaterial;
            var surface = Resources.Load<Material>("CrestLocalProbeSurface");
            CheckExample(surface != null, "Missing packed probe surface material");
            ocean.OceanMaterial = surface;
            var clock = new ExampleFixedTime();
            ocean.PushTimeProvider(clock);

            var target = new RenderTexture(320, 180, 24, RenderTextureFormat.ARGB32);
            var pixels = new Texture2D(320, 180, TextureFormat.RGBA32, false);
            var red = ProbeCubemap(Color.red, true);
            var green = ProbeCubemap(Color.green);
            var solidRed = ProbeCubemap(Color.red);
            red.name = "Directional red-green";
            green.name = "Solid green";
            solidRed.name = "Solid red";
            var probe = new GameObject("Box projection probe").AddComponent<ReflectionProbe>();
            var second = new GameObject("Atlas second probe").AddComponent<ReflectionProbe>();
            target.Create();
            var observer = new LocalProbeObserver { Camera = camera };
            CameraGraphPassRegistry.Register(observer);
            GameObject litControl = null;
            try
            {
                probe.mode = ReflectionProbeMode.Custom;
                second.enabled = false;
                Color32[] baseline = null, restored = null;
                if (runBox)
                {
                    QualitySettings.renderPipeline = boxPipeline;
                    settings.SetRenderer(0);
                    probe.customBakedTexture = red;
                    probe.transform.position = new Vector3(12, 0, 0);
                    probe.size = new Vector3(80, 50, 160);
                    probe.blendDistance = 1;
                    for (int i = 0; i < 12; i++) yield return null;
                    Color32[] changed = null, probeOff = null;
                    yield return ModeCapture(() => baseline = CaptureProbe(camera, target, pixels, "Forward", observer, "BoxOff"));
                    probe.boxProjection = true;
                    yield return ModeCapture(() => changed = CaptureProbe(camera, target, pixels, "Forward", observer, "BoxOn"));
                    probe.boxProjection = false;
                    yield return ModeCapture(() => restored = CaptureProbe(camera, target, pixels, "Forward"));
                    probe.enabled = false;
                    yield return ModeCapture(() => probeOff = CaptureProbe(camera, target, pixels, "Forward", observer, "ProbeOff"));
                    probe.enabled = true;
                    _localProbes.forwardMode = ActualProbeRenderer(settings);
                    for (int i = 0; i < baseline.Length; i++)
                    {
                        if (ProbeDifference(baseline[i], changed[i]) > 12) _localProbes.boxPixels++;
                        if (ProbeDifference(baseline[i], restored[i]) != 0) _localProbes.boxRestore++;
                        if (ProbeDifference(baseline[i], probeOff[i]) > 12) _localProbes.boxProbeResponse++;
                    }
                    var lit = Resources.Load<Material>("CrestLocalProbeLit");
                    CheckExample(lit != null, "Missing packed URP/Lit control");
                    litControl = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    litControl.name = "URP Lit probe control";
                    litControl.layer = 4;
                    litControl.transform.position = new Vector3(0, 1, -5);
                    litControl.GetComponent<Renderer>().sharedMaterial = lit;
                    probe.customBakedTexture = solidRed;
                    yield return ModeCapture(() => CaptureProbe(camera, target, pixels, "Forward", observer, "LitRed"));
                    probe.customBakedTexture = green;
                    yield return ModeCapture(() => CaptureProbe(camera, target, pixels, "Forward", observer, "LitGreen"));
                    litControl.SetActive(false);
                    SaveLocalProbes();
                }
                if (runAtlas)
                {
                    QualitySettings.renderPipeline = atlasPipeline;
                    settings.SetRenderer(1);
                    probe.transform.position = Vector3.zero;
                    probe.customBakedTexture = solidRed;
                    probe.size = second.size = new Vector3(160, 64, 160);
                    probe.blendDistance = second.blendDistance = 64;
                    second.mode = ReflectionProbeMode.Custom;
                    second.customBakedTexture = green;
                    Color32[] both = null, onlyGreen = null;
                    for (int i = 0; i < 4; i++) yield return null;
                    yield return ModeCapture(() => baseline = CaptureProbe(camera, target, pixels, "ForwardPlus"));
                    second.enabled = true;
                    yield return ModeCapture(() => both = CaptureProbe(camera, target, pixels, "ForwardPlus"));
                    probe.enabled = false;
                    yield return ModeCapture(() => onlyGreen = CaptureProbe(camera, target, pixels, "ForwardPlus"));
                    probe.enabled = true;
                    second.enabled = false;
                    yield return ModeCapture(() => restored = CaptureProbe(camera, target, pixels, "ForwardPlus"));
                    _localProbes.clusterMode = ActualProbeRenderer(settings);
                    for (int i = 0; i < both.Length; i++)
                    {
                        if (baseline[i].r - both[i].r > 5 && both[i].r - onlyGreen[i].r > 5 &&
                            onlyGreen[i].g - both[i].g > 5 && both[i].g - baseline[i].g > 5) _localProbes.atlasPixels++;
                        if (ProbeDifference(baseline[i], restored[i]) != 0) _localProbes.atlasRestore++;
                    }
                    SaveLocalProbes();
                }
                if (runBox)
                {
                    CheckExample(_localProbes.boxProbeResponse > 500, "Compiled Forward surface did not respond to probe registration");
                    CheckExample(_localProbes.boxPixels > 500 && _localProbes.boxRestore == 0, "Compiled box projection did not change and restore the surface");
                }
                if (runAtlas)
                    CheckExample(_localProbes.atlasPixels > 500 && _localProbes.atlasRestore == 0, "Compiled atlas did not blend and restore the surface");
                CheckExample(_errors == 0, "Local probe Player logged errors");
                _localProbes.passed = true;
            }
            finally
            {
                CameraGraphPassRegistry.Unregister(observer);
                Destroy(litControl);
                QualitySettings.renderPipeline = qualityPipeline;
                ocean.PopTimeProvider(clock);
                ocean.OceanMaterial = original;
                Destroy(probe.gameObject);
                Destroy(second.gameObject);
                Destroy(red);
                Destroy(green);
                Destroy(solidRed);
                Destroy(pixels);
                target.Release();
                Destroy(target);
            }
            SaveLocalProbes();
            Application.Quit(_errors == 0 ? 0 : 1);
        }

        static string ActualProbeRenderer(UniversalAdditionalCameraData settings)
        {
            var renderer = settings.scriptableRenderer;
            return renderer.GetType().GetProperty("renderingModeActual", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                ?.GetValue(renderer)?.ToString();
        }

        Color32[] CaptureProbe(Camera camera, RenderTexture target, Texture2D pixels, string expectedRenderer,
            LocalProbeObserver observer = null, string state = null)
        {
            CheckExample(ActualProbeRenderer(camera.GetUniversalAdditionalCameraData()) == expectedRenderer, "Unexpected actual probe renderer");
            var previous = RenderTexture.active;
            if (observer != null) observer.Capture = new LocalProbeCapture { state = state };
            try
            {
                RenderPipeline.SubmitRenderRequest(camera, new UniversalRenderPipeline.SingleCameraRequest { destination = target });
                RenderTexture.active = target;
                pixels.ReadPixels(new Rect(0, 0, target.width, target.height), 0, 0);
                var result = pixels.GetPixels32();
                if (observer != null)
                {
                    foreach (var pixel in result)
                        if (ProbeDifference(pixel, new Color32(0, 0, 255, 255)) > 12) observer.Capture.nonClearPixels++;
                    _localProbes.captures.Add(observer.Capture);
                    var directory = Path.GetDirectoryName(Argument("-crestProbeOutput", "LocalProbes.json"));
                    File.WriteAllBytes(Path.Combine(directory, state + ".png"), pixels.EncodeToPNG());
                }
                return result;
            }
            finally
            {
                if (observer != null) observer.Capture = null;
                RenderTexture.active = previous;
            }
        }

        static Cubemap ProbeCubemap(Color color, bool directional = false)
        {
            var cube = new Cubemap(16, TextureFormat.RGBA32, true);
            var face = new Color[16 * 16];
            for (int i = 0; i < 6; i++)
            {
                Array.Fill(face, directional && i == (int)CubemapFace.PositiveX ? Color.green : color);
                cube.SetPixels(face, (CubemapFace)i);
            }
            cube.Apply();
            return cube;
        }

        static int ProbeDifference(Color32 a, Color32 b) =>
            Mathf.Abs(a.r - b.r) + Mathf.Abs(a.g - b.g) + Mathf.Abs(a.b - b.b);
    }
}
#endif
