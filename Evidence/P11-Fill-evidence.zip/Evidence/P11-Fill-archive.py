from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET,datetime
E=Path('Evidence');summary=E/'P11-Fill-summary.json';x=json.loads(summary.read_text());x['recordedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();x['originalPreservation']=json.loads((E/'P11-Fill-source-check.json').read_text(encoding='utf-8-sig'));summary.write_text(json.dumps(x,indent=2)+'\n')
raw=[p for p in E.glob('P11-Fill-*') if p.suffix!='.zip' and p.name not in ['P11-Fill-summary.json','P11-Fill-files.json']]
sources=[Path(n) for n in ['Assets/Crest/URP/Tests/Editor/OriginalExamplesConfigurationsTests.cs','Assets/Crest/URP/Tests/Editor/OriginalExamplesConfigurationsTests.cs.meta','Assets/Crest/URP/Tests/Editor/MaskTimingProbe.shader','Assets/Crest/Crest-Examples/Examples/Scripts/MaskFill.cs','Assets/Crest/Crest-Examples/Examples/Scripts/CustomPassForCamera.cs','Assets/Crest/Crest-Examples/Examples/Shaders/Resources/MaskFill.shader','Assets/Crest/Crest-Examples/Examples/Shaders/Masked.shader','Assets/Crest/URP/Runtime/CameraGraphPassRegistry.cs','Assets/Crest/URP/Runtime/CrestBackgroundFeature.cs','Assets/Crest/Crest/Scripts/Underwater/UnderwaterRenderer.cs','Evidence/OriginalExamples-controls-inside-probe-Direct3D11.txt','Evidence/OriginalExamples-controls-inside-probe-DX11.xml']]
assemblies=list(Path('Library/ScriptAssemblies').glob('Crest*.dll'));assert len(assemblies)==7
logs=[E/f'EditMode-{api}-focused.log' for api in ['DX11','DX12']]
files=sorted(set(raw+sources+assemblies+logs));archive=E/'P11-Fill-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.as_posix())
manifest=[dict(path=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest().upper(),bytes=p.stat().st_size) for p in files]
with zipfile.ZipFile(archive) as z:
 for f in manifest:assert hashlib.sha256(z.read(f['path'])).hexdigest().upper()==f['sha256']
(E/'P11-Fill-files.json').write_text(json.dumps(dict(archive=archive.as_posix(),sha256=hashlib.sha256(archive.read_bytes()).hexdigest().upper(),entries=manifest),indent=2)+'\n')
with zipfile.ZipFile(E/'P11-Fill-before.zip') as z:
 for n in ['Evidence/EditMode-DX11-focused.xml','Evidence/EditMode-DX12-focused.xml']:Path(n).write_bytes(z.read(n))
for p in raw:p.unlink()
print('Archived/verified',len(files),'files with7 actual Editor DLLs; restored original focused reports')
