from pathlib import Path
import zipfile
E=Path('Evidence')
with zipfile.ZipFile(E/'P11-Fill-inventory.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ['Evidence/P11-Fill-Direct3D11.txt','Evidence/EditMode-DX11-focused.xml','Evidence/EditMode-DX11-focused.log','Assets/Crest/URP/Tests/Editor/OriginalExamplesConfigurationsTests.cs','Library/ScriptAssemblies/Crest.URP.Tests.dll']:z.write(n,n)
p=Path('Assets/Crest/URP/Tests/Editor/OriginalExamplesConfigurationsTests.cs');s=p.read_text(encoding='utf-8');s=s.replace('using Crest.Examples;','using Crest.Examples;\nusing Crest.URP;\nusing UnityEngine.Rendering.RenderGraphModule;')
s=s.replace('    RenderTexture _target;float _scale;int _capture;','''    RenderTexture _target;float _scale;int _capture;
    Material _referenceMaterial,_probeMaterial;Shader _referenceShader;ReferencePass _reference;
    GameObject _positive;List<MeshFilter> _fillMeshes;MeshFilter[] _originalMeshes;
    readonly List<RenderTexture> _resources=new List<RenderTexture>();
    sealed class ReferencePass : ICameraGraphPass
    {
        public Camera Camera;public RTHandle Colour,Depth,Front;public Material Material,Probe;public List<MeshFilter> Meshes;
        public RenderPassEvent Stage=>(RenderPassEvent)((int)RenderPassEvent.BeforeRenderingPrePasses+1);
        sealed class Data{public TextureHandle Colour,Depth,Front;public Material Material,Probe;public MeshFilter[] Meshes;public Matrix4x4 View,Projection;public int Width,Height;}
        public void Record(RenderGraph graph,ContextContainer frame)
        {
            var camera=frame.Get<UniversalCameraData>();if(camera.camera!=Camera)return;
            using var b=graph.AddUnsafePass<Data>("Test original fill shader reference",out var d);
            d.Colour=graph.ImportTexture(Colour);d.Depth=graph.ImportTexture(Depth);d.Front=graph.ImportTexture(Front);d.Material=Material;d.Probe=Probe;d.Meshes=Meshes.ToArray();
            d.View=camera.GetViewMatrix();d.Projection=camera.GetProjectionMatrix();d.Width=Colour.rt.width;d.Height=Colour.rt.height;
            b.UseTexture(d.Colour,AccessFlags.Write);b.UseTexture(d.Depth,AccessFlags.Write);b.UseTexture(d.Front,AccessFlags.Write);b.UseAllGlobalTextures(true);b.AllowGlobalStateModification(true);b.AllowPassCulling(false);
            b.SetRenderFunc((Data data,UnsafeGraphContext context)=>
            {
                var cmd=CommandBufferHelpers.GetNativeCommandBuffer(context.cmd);cmd.SetViewport(new Rect(0,0,data.Width,data.Height));
                cmd.SetRenderTarget(data.Front);cmd.DrawProcedural(Matrix4x4.identity,data.Probe,0,MeshTopology.Triangles,3);
                cmd.SetRenderTarget(data.Colour,data.Depth);cmd.ClearRenderTarget(true,true,Color.black);cmd.SetViewProjectionMatrices(data.View,data.Projection);
                foreach(var mesh in data.Meshes)if(mesh!=null)cmd.DrawMesh(mesh.sharedMesh,mesh.transform.localToWorldMatrix,data.Material,0,0);
                cmd.SetViewProjectionMatrices(data.View,data.Projection);
            });
        }
    }
    string ExpandReference(string file)
    {
        string text=File.ReadAllText(file);
        return System.Text.RegularExpressions.Regex.Replace(text,@"(?m)^\\s*#include\\s+""([^""]+)""[^\\r\\n]*",m=>
        {string path=Path.GetFullPath(Path.Combine(Path.GetDirectoryName(file),m.Groups[1].Value));return File.Exists(path)?ExpandReference(path):m.Value;});
    }
    RenderTexture Resource(RenderTextureFormat format,int depth)
    {var t=new RenderTexture(640,360,depth,format,RenderTextureReadWrite.Linear);t.Create();_resources.Add(t);return t;}
    static float[] ReadMask(RenderTexture texture)
    {var r=AsyncGPUReadback.Request(texture,0,TextureFormat.RFloat);r.WaitForCompletion();Assert.That(r.hasError,Is.False);var values=r.GetData<float>().ToArray();Assert.That(values.All(float.IsFinite),Is.True);return values;}
    static int Changed(Color32[] a,Color32[] b)=>a.Zip(b,(x,y)=>Math.Abs(x.r-y.r)+Math.Abs(x.g-y.g)+Math.Abs(x.b-y.b)>6?1:0).Sum();''')
needle='        _target=new RenderTexture(640,360,24,RenderTextureFormat.ARGB32);_target.Create();\n        for(int pose=0;pose<3;pose++)'
s=s.replace(needle,'''        _target=new RenderTexture(640,360,24,RenderTextureFormat.ARGB32);_target.Create();
        string sourcePath=Path.GetFullPath("../../work/crest-upstream/crest/Assets/Crest/Crest-Examples/Examples/Shaders/Resources/MaskFill.shader");
        string code=ExpandReference(sourcePath).Replace("Shader \\"Hidden/Crest/Examples/Mask Fill\\"","Shader \\"Hidden/Crest/Tests/OriginalFillReference\\"");
        File.WriteAllText(report+"-reference.shader.txt",code);_referenceShader=ShaderUtil.CreateShaderAsset(code,false);_referenceMaterial=new Material(_referenceShader);ShaderUtil.CompilePass(_referenceMaterial,0,true);
        Assert.That(ShaderUtil.GetShaderMessages(_referenceShader).Where(m=>m.severity==UnityEditor.Rendering.ShaderCompilerMessageSeverity.Error),Is.Empty);
        _probeMaterial=new Material(Shader.Find("Hidden/Crest/Tests/MaskTimingProbe"));_probeMaterial.SetInt("_ProbeField",1);
        _reference=new ReferencePass{Camera=camera,Colour=RTHandles.Alloc(Resource(RenderTextureFormat.RFloat,0)),Depth=RTHandles.Alloc(Resource(RenderTextureFormat.Depth,24)),Front=RTHandles.Alloc(Resource(RenderTextureFormat.RFloat,0)),Material=_referenceMaterial,Probe=_probeMaterial,Meshes=meshes};CameraGraphPassRegistry.Register(_reference);
        var originalPosition=camera.transform.position;var originalRotation=camera.transform.rotation;
        for(int pose=0;pose<3;pose++)''')
s=s.replace('            int nonzero=values.Count(v=>v>0),ones=values.Count(v=>v==1);','''            int nonzero=values.Count(v=>v>0),ones=values.Count(v=>v==1);
            var reference=ReadMask(_reference.Colour.rt);var front=ReadMask(_reference.Front.rt);float error=values.Zip(reference,(a,b)=>Math.Abs(a-b)).Max();
            File.AppendAllText(report+".txt",$"ReferencePose={pose}; ReferenceNonzero={reference.Count(v=>v>0)}; NativeReferenceMaxError={error:R}; FrontNonzero={front.Count(v=>v>0)}\\n");
            Assert.That(error,Is.LessThan(.000001f));Assert.That(front.Count(v=>v>0),Is.GreaterThan(1000));''')
s=s.replace('        ocean.PopTimeProvider(clock);\n    }\n    Color32[] Capture(Camera camera)','''        _fillMeshes=meshes;_originalMeshes=meshes.ToArray();
        _positive=GameObject.CreatePrimitive(PrimitiveType.Quad);_positive.name="Fill source-reference positive control";_positive.GetComponent<Renderer>().enabled=false;
        _positive.transform.position=Vector3.zero;_positive.transform.rotation=Quaternion.Euler(0,180,0);_positive.transform.localScale=Vector3.one*8;
        camera.transform.SetPositionAndRotation(originalPosition,originalRotation);meshes.Clear();meshes.Add(_positive.GetComponent<MeshFilter>());
        var positive=Capture(camera);var native=ReadMask((RenderTexture)typeof(MaskFill).GetField("_texture",Private).GetValue(fill));var expected=ReadMask(_reference.Colour.rt);
        float positiveError=native.Zip(expected,(a,b)=>Math.Abs(a-b)).Max();int positivePixels=native.Count(v=>v>0);
        callbacks[0].enabled=false;var positiveOff=Capture(camera);callbacks[0].enabled=true;var positiveRestore=Capture(camera);
        int colourDelta=Changed(positive,positiveOff),restore=positive.Zip(positiveRestore,(a,b)=>a.Equals(b)?0:1).Sum();
        File.AppendAllText(report+".txt",$"PositiveBackfaceMask={positivePixels}; ReferenceMaxError={positiveError:R}; FillConsumerChanged={colourDelta}; RestoredPixels={restore}\\n");
        Assert.That(positivePixels,Is.GreaterThan(1000));Assert.That(positiveError,Is.LessThan(.000001f));Assert.That(colourDelta,Is.GreaterThan(200));Assert.That(restore,Is.Zero);
        meshes.Clear();meshes.AddRange(_originalMeshes);ocean.PopTimeProvider(clock);
    }
    Color32[] Capture(Camera camera)''')
s=s.replace('        OceanRenderer.EnableGraphicsInBatchMode=false;if(Application.isPlaying)yield return new ExitPlayMode();\n        if(_target!=null)', '''        if(_fillMeshes!=null){_fillMeshes.Clear();_fillMeshes.AddRange(_originalMeshes.Where(m=>m!=null));}
        if(_reference!=null){CameraGraphPassRegistry.Unregister(_reference);_reference.Colour.Release();_reference.Depth.Release();_reference.Front.Release();}
        OceanRenderer.EnableGraphicsInBatchMode=false;if(Application.isPlaying)yield return new ExitPlayMode();
        foreach(var t in _resources){t.Release();Object.DestroyImmediate(t);}_resources.Clear();
        if(_positive!=null)Object.DestroyImmediate(_positive);if(_referenceMaterial!=null)Object.DestroyImmediate(_referenceMaterial);if(_probeMaterial!=null)Object.DestroyImmediate(_probeMaterial);if(_referenceShader!=null)Object.DestroyImmediate(_referenceShader);
        if(_target!=null)''')
p.write_text(s,encoding='utf-8')
