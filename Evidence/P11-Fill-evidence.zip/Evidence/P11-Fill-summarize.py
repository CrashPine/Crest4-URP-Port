from pathlib import Path
import json,hashlib,re,xml.etree.ElementTree as ET
E=Path('Evidence');results=[]
for api in ['DX11','DX12']:
 p=E/f'P11-Fill-{api}.xml';assert p.read_bytes()==(E/f'EditMode-{api}-focused.xml').read_bytes();root=ET.parse(p).getroot();assert root.attrib['result']=='Passed' and len(list(root.iter('test-case')))==1
 text=(E/f'P11-Fill-Direct3D{api[2:]}.txt').read_text();poses=[]
 for line in text.splitlines():
  if line.startswith('ReferencePose='):
   vals={k:float(v.replace(',','.')) for k,v in re.findall(r'(ReferencePose|ReferenceNonzero|NativeReferenceMaxError|FrontNonzero)=([-+]?\d+(?:[,.]\d+)?)',line)};poses.append(vals)
 assert len(poses)==4 and all(p['NativeReferenceMaxError']==0 and p['ReferenceNonzero']==0 for p in poses) and poses[3]['FrontNonzero']==0
 vals={k:int(re.search(r'\b'+k+r'=(\d+)',text).group(1)) for k in ['OutsideMaskInteriorCompared','OutsideMaskChanged','PositiveBackfaceMask','FillConsumerChanged','RestoredPixels']};assert vals['PositiveBackfaceMask']>1000 and vals['FillConsumerChanged']>200 and vals['OutsideMaskChanged']==0 and vals['RestoredPixels']==0
 logs=(E/f'EditMode-{api}-focused.log').read_text(errors='replace');warnings={k:len(re.findall(p,logs,re.I)) for k,p in {'compileErrors':r'error CS\d+','shaderErrors':'Shader error in','renderData':'RenderData validation failed','persistent':'Persistent allocates','evictable':'evictable'}.items()};assert not any(warnings.values())
 results.append(dict(api=api,passed=1,poses=poses,positive=vals,warnings=warnings))
x=json.loads((E/'Build-checkpoint.json').read_text(encoding='utf-8-sig'))
for a in x['runtimeSources']+x['materialSources']:assert hashlib.sha256(Path(a['path']).read_bytes()).hexdigest().upper()==a['sha256'],a['path']
for group,key in [('builds','assembly'),('packedAssets','path')]:
 for a in x[group]:assert hashlib.sha256((Path('Builds')/a['configuration']/a[key]).read_bytes()).hexdigest().upper()==a['sha256']
refs=[(E/f'P11-Fill-Direct3D{api}-reference.shader.txt').read_bytes() for api in ['11','12']];assert refs[0]==refs[1]
(E/'P11-Fill-summary.json').write_text(json.dumps({'validation':'P11.2 scoped source-equivalent mask/positive consumer control Passed1/API','results':results,'referenceProvenance':json.loads((E/'P11-Fill-reference-provenance.json').read_text()),'historicalInsidePose':{'pose':[0,-1,-3],'evidence':'Evidence/OriginalExamples-controls-inside-probe-Direct3D11.txt','sha256':hashlib.sha256((E/'OriginalExamples-controls-inside-probe-Direct3D11.txt').read_bytes()).hexdigest().upper()},'normalRuntimeMaterialsAnd12ArtifactsUnchanged':True,'normalCheckpoint':'e4cbf02 full117+interactive2/API; no new full119 or Player rebuild claimed','limits':'Original shader source compared under identical URP matrices/native front-depth; not a complete Built-in renderer/RGB/all-view/XR reference. Temporary invisible8m backface quad replaces fill producer only for explicit positive probe; original consumer/camera/volume retained. Existing source-view>200 failure not relabeled passed; its all-zero producer makes it an invalid positive-control expectation.'},indent=2)+'\n')
print(json.dumps(results,indent=2))
