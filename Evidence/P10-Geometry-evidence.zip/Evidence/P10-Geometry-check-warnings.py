from pathlib import Path
import json,re
E=Path('Evidence')
checks={}
for name in ['EditMode-DX11','EditMode-DX11-interactive','EditMode-DX12','EditMode-DX12-interactive','Development-DX11','Release-DX11']:
 p=E/(name+'.log')
 checks[name]={key:len(re.findall(pattern,p.read_text(errors='replace'),re.I)) for key,pattern in {'persistentAllocation':'Found [0-9]+ leak', 'renderData':'RenderData validation failed','shaderError':'Shader error in','compileError':r'error CS\d+', 'evictable':'evictable.*(leak|allocation)'}.items()}
print(json.dumps(checks,indent=2))
