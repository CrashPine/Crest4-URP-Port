$ErrorActionPreference='Stop'
./Tools/Run-Unity.ps1 -Editor 'C:/Program Files/Unity/Hub/Editor/6000.6.5f1/Editor/Unity.exe' -Action EditMode -GraphicsAPI DX11 -TestFilter OceanGeometryLifetimeTests
